"""
This is the writing module for the score board
Contains functions to write/get and display the board
"""
import pygame
import os


def get_score_board():
    """
    Reads from a file name hs.dat that contains the highscore

    Returns:
        List: list of the names on the board
    """
    file = open('hs.dat', 'r')
    temp = file.read()
    file.close()
    data = temp.split(",")
    result = []
    for i in range(0, len(data)-1, 2):
        result.append((data[i], int(data[i+1])))
    return result


def write_score(hs):
    """
    Opens the file to write new data into it.

    hs (file): the file that contains the data

    """
    file = open('hs.dat', 'w')
    for i in hs:
        data = i[0] + ',' + str(i[1]) + ','
        file.write(data)
    file.close()


def is_record(value):
    """
    Checks to see if the new score is higher then recorded
    scores.

    Arguments:
        value:
    Returns:
        bool: return true if the score is greater or has
        less then 5 entries
    """
    hs = get_score_board()
    for i in range(len(hs)):
        if value > hs[i][1]:
            return True
    if len(hs) == 5:
        return False
    else:
        return True


def new_record(value, name):
    """
    When a new entry gets place, this function places it in the
    correct order in the file
    Arguments:
        value (int): the score
        name (string): the name

    """
    hs = get_score_board()
    inserted = False
    for i in range(0, len(hs)):
        if value > hs[i][1]:
            hs.insert(i, (name, value))
            hs = hs[0:5]
            inserted = True
            break
        elif value == hs[i][1] and i < 4:
            hs.insert(i+1, (name, value))
            hs = hs[0:5]
            inserted = True
            break
    if not inserted:
        hs.append((name, value))
    write_score(hs)


def show_board(screen, screenSize):
    """
    Shows the current player in the file onto the display
    Arguments:
        screen (pygame.display): The display object
        screenSize (pygame.display.Info): the height and width of the display
    """
    running = True
    
    title_font = pygame.font.Font(os.path.join('mortis.ttf'), 50)
    name_font = pygame.font.Font(os.path.join('mortis.ttf'), 50)
    NEON_PINK = (254, 0, 205)
    screen.fill((0, 0, 0))
    
    screen.blit(title_font.render("HALL OF LEGENDS", False, NEON_PINK),
                (screenSize.current_w * .39, screenSize.current_h * .25))
    hs = get_score_board()
    y_postion = 200
    if len(hs) == 0:
        screen.blit(name_font.render('EMPTY', False, NEON_PINK),
                    (screenSize.current_w * .39, screenSize.current_h * .25))
    for i in range(0, len(hs)):
        screen.blit(name_font.render(str(i+1) + '. ' + hs[i][0], False, NEON_PINK),
                    (screenSize.current_w * .39, screenSize.current_h * .19 + y_postion))
        screen.blit(name_font.render(str(hs[i][1]), False, NEON_PINK),
                    (screenSize.current_w * .67, screenSize.current_h * .19 + y_postion))
        y_postion += 50
    pygame.display.update()
    
    while running:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE or event.key == pygame.K_BACKSPACE:
                        running = False
                        

