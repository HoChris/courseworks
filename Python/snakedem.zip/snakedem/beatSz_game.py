"""
This is the actual game module. It is quite important to run
this module you will need to have Librosa to read in the wav file

    On Python 3.5 and using PyPI run the following command from the
    command line
        pip install librosa

This module does not run without the beatSz_menu driver module
"""
from game_rules import *
import librosa


def game(screen, clock, screenSize):
    """
    This is the main game loop. Basically it loads all the music and drawings.
    Also to note this is where librosa is utilized by reading in and outputing
    the Beats per second of the background music.

    Arguments:

        screen (pygame.display): The display object
        clock (pygame.time.clock): the clock speed
        screenSize (pygame.display.Info): the height and width of the display

    Returns: score (int) : the resulting score of the points
    """
    running = True
    #sets the colors
    SNAKE = (255, 255, 255)
    BORDER = (0, 134, 205)
    #the song name
    SONGNAME = "westsidelake.wav"


    pygame.mixer.music.load(SONGNAME)
    pygame.mixer.music.play()
    y, sr = librosa.load(SONGNAME)
    tempo, beats = librosa.beat.beat_track(y=y, sr=sr)
    """
        librosa loads the wave file and save it into
             y(string): string name
             sr(samplerate): sample rate default
        and is put into the function librosa.beat.beat_track which
        outputs
            tempo(list): the BMP of the song
            beats(list): the individual beats of the song
    """
    beatpersec = []
    for i in beats:
        bps = i/tempo
        beatpersec.append(int(bps))
    beatpersec.reverse()
    beatmax = int(max(beatpersec) * .1)

    """
        Takes the BPM provided by librosa and divides each beat by tempo
        to result in a manageable integer to be passed into the gaps

        gaps (int): hold the incrementing beats of the the song from the list
                    of beats. If the list is empty it default to the maximum
                    speed from the list
    """
    gaps = 0

    upper_border = pygame.Rect(screenSize.current_w * .19, screenSize.current_h * .23,
                               screenSize.current_w * .62, screenSize.current_h * .02)
    right_border = pygame.Rect(screenSize.current_w * .80, screenSize.current_h * .23,
                               screenSize.current_w * .01, screenSize.current_h * .58)
    left_border = pygame.Rect(screenSize.current_w * .19, screenSize.current_h * .23,
                              screenSize.current_w * .01, screenSize.current_h * .58)
    down_border = pygame.Rect(screenSize.current_w * .19, screenSize.current_h * .80,
                              screenSize.current_w * .62, screenSize.current_h * .02)

    snake = [(512 + gaps, 384 + gaps), (512 + gaps, 360 + gaps)]

    direction = 'DOWN'

    food = new_food(screen, snake, screenSize, gaps)
    big_point = None
    b_point_timer = 0
    eaten = True
    eat_cd = 1

    x_change = 0
    y_change = 0
    
    score = 0

    font = pygame.font.Font(os.path.join('mortis.ttf'), 28)
    countdown_font = pygame.font.Font(os.path.join('mortis.ttf'), 100)

    up_pressed = False
    right_pressed = False
    down_pressed = False
    left_pressed = False
    
    countdown = True

    while running:
        """
        After initialization here is the logic for the player controls
        """
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    if event.key == pygame.K_UP and not direction == 'DOWN' \
                            and not right_pressed and not left_pressed:
                        direction = 'UP'
                        up_pressed = True
                    elif event.key == pygame.K_DOWN and not direction == 'UP' \
                            and not right_pressed and not left_pressed:
                        direction = 'DOWN'
                        down_pressed = True
                    elif event.key == pygame.K_RIGHT and not direction == 'LEFT' \
                            and not up_pressed and not down_pressed:
                        direction = 'RIGHT'
                        right_pressed = True
                    elif event.key == pygame.K_LEFT and not direction == 'RIGHT' \
                            and not up_pressed and not down_pressed:
                        direction = 'LEFT'
                        left_pressed = True

        up_pressed = False
        right_pressed = False
        down_pressed = False
        left_pressed = False

        if score <= random.randint(13, 20):
            """
            Better control variable speed provided from the output of
            the music.
            """
            if direction == 'RIGHT':
                x_change = 10
                y_change = 0
            elif direction == 'LEFT':
                x_change = -10
                y_change = 0
            elif direction == 'UP':
                x_change = 0
                y_change = -10
            elif direction == 'DOWN':
                x_change = 0
                y_change = 10
        else:
            """
            Better control variable speed provided from the output of
            the music.
            """
            if len(beatpersec) == 0:
                gaps = beatmax
            else:
                gaps = int(beatpersec.pop() * .1)
            if direction == 'RIGHT':
                x_change = 10 + gaps
                y_change = 0
            elif direction == 'LEFT':
                x_change = -10 - gaps
                y_change = 0
            elif direction == 'UP':
                x_change = 0
                y_change = -10 - gaps
            elif direction == 'DOWN':
                x_change = 0
                y_change = 10 + gaps

        status = check_ahead(screen, (snake[0][0] + x_change), (snake[0][1] + y_change), gaps)
        """
        Depending on the status the snake will either add another segment to th body, keep moving
        ,display bonus point, or game over
        """

        if status == 'EAT'or status == 'NOTHING':
            snake.insert(0, (snake[0][0] + x_change, snake[0][1] + y_change))
        if status == 'EAT':
            eaten = True
            eat_cd += 4
            food = new_food(screen, None, screenSize, gaps)
            score += 1
            if random.randint(1, 8) == 8 and not big_point:
                big_point = new_food(screen, [food], screenSize, gaps)
                b_point_timer = 5
        if status == 'BONUS':
            big_point = None
            score += 6
            eat_cd += 8
        if not eaten and eat_cd == 0:
            snake = snake[0:-1]
        else:
            eaten = False
            eat_cd -= 1
        if status == 'GAME_OVER':
            pygame.mixer.music.fadeout(5000)
            return score
        if b_point_timer:
            b_point_timer -= (clock.get_time() / 1000)
            if b_point_timer <= 0:
                big_point = None
                b_point_timer = 0

        screen.fill((0, 0, 0))
        pygame.draw.rect(screen, BORDER, upper_border)
        pygame.draw.rect(screen, BORDER, right_border)
        pygame.draw.rect(screen, BORDER, left_border)
        pygame.draw.rect(screen, BORDER, down_border)
        pygame.draw.rect(screen, (35, 142, 35), pygame.Rect(food[0], food[1], 10, 10))

        if big_point:
            """
            draws the bonus point
            """
            pygame.draw.rect(screen, (255, 215, 0), pygame.Rect(big_point[0], big_point[1], 10, 10))
            screen.blit(font.render(str(round(b_point_timer, 1)), False, (255, 255, 0)),
                        (screenSize.current_w * .32, screenSize.current_h * .18))

        screen.blit(font.render("Score: " + str(score), False, (255, 255, 0)),
                    (screenSize.current_w * .22, screenSize.current_h * .18))

        for dot in snake:
            """
            draws the snake
            """
            pygame.draw.rect(screen, SNAKE, pygame.Rect(dot[0], dot[1], 10, 10))

        pygame.display.update()

        if countdown:
            """
            draws and display the countdown before the game plays
            """
            update_rect = pygame.Rect(screenSize.current_w * .5, screenSize.current_h * .45, 100, 100)
            countdown = False
            for i in range(3, 0, -1):
                pygame.draw.rect(screen, (0, 0, 0), update_rect)
                screen.blit(countdown_font.render(str(i), False, BORDER),
                            (screenSize.current_w * .5, screenSize.current_h * .45))
                pygame.display.update(update_rect)
                pygame.time.delay(1000)

        clock.tick(25)
