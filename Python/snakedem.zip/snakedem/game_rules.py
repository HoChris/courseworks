"""
This is the game rules/ logic for the game module
Checking the status of the game and placing new points
Also show the player to enter the name if high score achieved
"""
import random
from scoreboard import *


def check_ahead(screen, x, y, gaps):
    """
    Checks ahead of the snake head and returns the appropiate status as
    a String

     Arguments:

        screen (pygame.display): The display object
        x (int) : the x-coordinate
        y (int) : the y-coordinate
        gaps(int): the varible input step from the music
     Returns:
         String: status of the check
    """
    color = screen.get_at((x, y))
    color_out = screen.get_at((x, y - 5))
    color_out2 = screen.get_at((x + 5, y))
    if color[0] == 35 or color_out[0] == 35 or color_out2[0] == 35:
        return 'EAT'
    elif color[1] == 215 or color_out[1] == 215 or color_out2[1] == 215:
        return 'BONUS'
    elif color[0] == 255 or color[2] == 205:
        return 'GAME_OVER'
    elif color[0] == 0:
        return 'NOTHING'


def new_food(screen, snake, screenSize, gaps):
    """
    Generates the new food point at random range of the display box

    Arguments:
        screen (pygame.display): The display object
        screenSize (pygame.display.Info): the width and height of current screen
        gaps(int): the variable input step from the music

    Returns:
         x (int) : the x-coordinate
        y (int) : the y-coordinate
    """
    while True:
        x = random.randrange(int(screenSize.current_w * .20), int(screenSize.current_w * .60), step=10)
        y = random.randrange(int(screenSize.current_h * .25), int(screenSize.current_h * .79), step=10)
        if check_ahead(screen, x, y, gaps) == 'NOTHING':
            if snake:
                if snake.count((x + gaps, y + gaps)) == 0:
                    return x, y
            else:
                return x, y


def input_name(screen, screenSize):
    """
    This message is prompted after the user loses the game. Asks the user
    for name.

    Arguments:
        screen (pygame.display): The display object
        screenSize (pygame.display.Info): the width and height of current screen

    """
    COLOR = (0, 134, 205)
    running = True
    clock = pygame.time.Clock()

    name = ""
    name_font = pygame.font.Font(os.path.join('mortis.ttf'), 30)
    name_border = pygame.Rect(screenSize.current_w * .46, screenSize.current_h * .41
                              , screenSize.current_w * .19, screenSize.current_h * .003)
    update_rect = pygame.Rect(screenSize.current_w * .35, screenSize.current_h * .23,
                              screenSize.current_w * .35, screenSize.current_h * .35)
    upper_border = pygame.Rect(screenSize.current_w * .25, screenSize.current_h * .23,
                               screenSize.current_w * .62, screenSize.current_h * .02)
    right_border = pygame.Rect(screenSize.current_w * .80, screenSize.current_h * .23,
                               screenSize.current_w * .01, screenSize.current_h * .58)
    left_border = pygame.Rect(screenSize.current_w * .25, screenSize.current_h * .23,
                              screenSize.current_w * .01, screenSize.current_h * .58)
    down_border = pygame.Rect(screenSize.current_w * .25, screenSize.current_h * .80,
                              screenSize.current_w * .62, screenSize.current_h * .02)

    while running:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_RETURN:
                        if name:
                            return name.upper()
                    elif event.key == pygame.K_BACKSPACE:
                        name = name[0:-1]
                    else:
                        if not len(name) > 12:
                            name = name + event.unicode
        pygame.draw.rect(screen, (0, 0, 0), update_rect)
        screen.blit(name_font.render("We did it Reddit, HighScore.", False, COLOR),
                    (screenSize.current_w * .35, screenSize.current_h * .35))
        screen.blit(name_font.render("Enter name: ", False, COLOR),
                    (screenSize.current_w * .35, screenSize.current_h * .38))
        screen.blit(name_font.render(name.upper(), False, COLOR),
                    (screenSize.current_w * .46, screenSize.current_h * .38))
        pygame.draw.rect(screen, COLOR, name_border)
        pygame.draw.rect(screen, COLOR, upper_border)
        pygame.draw.rect(screen, COLOR, right_border)
        pygame.draw.rect(screen, COLOR, down_border)
        pygame.draw.rect(screen, COLOR, left_border)
        pygame.display.update(update_rect)
        clock.tick(25)
