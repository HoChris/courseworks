Backstory:
	This game came to be when my young cousin was playing an old snake game. He mentioned it was
	too slow and boring to hold any interest. I mentioned to him that I could build a better version like adding music to the game mechanics. Initially it started with the idea to have the music influnce the game some how like make the snake jump to the rythm. This became very problematic because the music would jump into the wall and end the game. So instead the music addes incrementaly to the game gradually. I thought it would be neat if I could build this game and have my cousin play it.

HOW TO RUN:
 assuming you have python 3.5 and pygame installed 
 from the command line in windows:
  pip install librosa

  Librosa is a powerful tool that can anaylze music and output many many different 
  sets of data. From pitch, tolerances, BPM, and many more 
  This following program only utlizies the reading of the BPM feature to gain
  variable input from the background music.

  after the library has finished installing run the following:
  	python beatSx_menu.py
  this will launch the game

 HOW TO PLAY:
 after runing the game the player will have 3 options:
 1. play
 2. view the highscores
 3  exit the game
 
 At the menu the player can press the following
 	THE CONTROLS:
 	 1: play
	 2: view the highscores
	 3:  exit the game
	 ESC: Back or Exit
 At the GAME the player can press the following
 	THE CONTROLS:
	 	LEFT_ARROW: Left
	 	RIGHT_ARROW: Right
	 	UP_ARROW: Up
	 	DOWN_ARROW: Down
	 	ESC: Back or Exit
	 when the game is lost player can type in the name to
	 record highscore
 THE GOAL:
 	To get the highest score on the leader board. The game is challenging. The speed changes 
 	as the player reaches a RANDOM score greater and 13 to 17 points. Then the music addes input 
 	increments to the snake steps.
 		The player can visually see the change taking place. The segments of the snake move further apart as the speed increases.
 	The Green squares are 1 Point
 	The Yellow Squares are 6 Points and have a given time limit.
 	The current score is diplayed to the user in the upper left. The timer for the yellow squares are display when the yellow square is on the field.


