"""
This is the Main Driver module for the Game. When run the display
will come up and show the user selections to choose from.

    Run the program from the command line:
        python beatSz_menu.py

This file need to import
    from beatSz_game import game
    from game_rules import *
    from scoreboard import *
in order to function.
"""
from beatSz_game import game
from game_rules import *
from scoreboard import *


pygame.init()
screenSize = pygame.display.Info()
screen = pygame.display.set_mode((screenSize.current_w, screenSize.current_h), pygame.FULLSCREEN)
pygame.display.set_caption('beatSzzzzz')
running = True
NEON_PINK = (254, 0, 205)
beat_font = pygame.font.Font(os.path.join('mortis.ttf'), 79)
font = pygame.font.Font(os.path.join('mortis.ttf'), 40)
pygame.mouse.set_visible(False)
clock = pygame.time.Clock()

pygame.mixer.music.load("brainpower.wav")
pygame.mixer.music.play(-1)

while running:
    # Displays Menu for the user selection
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_1:
                        pygame.mixer.music.stop()
                        #runs the game from beatSz_game
                        score = game(screen, clock, screenSize)
                        pygame.mixer.music.load("brainpower.wav")
                        pygame.mixer.music.play(-1)
                        if score and is_record(score):
                            name = input_name(screen, screenSize)
                            new_record(score, name)
                            show_board(screen, screenSize)
                            # get the name to be added to the board
                    elif event.key == pygame.K_2:
                        show_board(screen, screenSize)
                    elif event.key == pygame.K_3:
                        running = False

        #Draws the text to the screen
        screen.fill((0, 0, 0))
        screen.blit(beat_font.render("beatSzzzz", False, NEON_PINK), (screenSize.current_w * .39, screenSize.current_h * .25))
        screen.blit(font.render("Play", False, NEON_PINK), (screenSize.current_h * .75, screenSize.current_w * .20))
        screen.blit(font.render("The Legends", False, NEON_PINK), (screenSize.current_h * .75, screenSize.current_w * .23))
        screen.blit(font.render("Quit", False, NEON_PINK), (screenSize.current_h * .75, screenSize.current_w * .26))
        screen.blit(font.render("1.", False, NEON_PINK), (screenSize.current_w * .40, screenSize.current_h * .355))
        screen.blit(font.render("2.", False, NEON_PINK), (screenSize.current_w * .40, screenSize.current_h * .412))
        screen.blit(font.render("3.", False, NEON_PINK), (screenSize.current_w * .40, screenSize.current_h * .462))
        pygame.display.update()

        clock.tick(25)
