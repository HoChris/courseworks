#include <iostream>
#include <fstream>
#include <set>
#include <string>
#include <algorithm>
#include <sstream>	
#include <iterator>	


using namespace std;
class Document {

public:
	std::set<std::string> doc;
	double getESize() { return doc.size(); };
	void readInWords(std::string& file);
	void printSet();
};


void Document::readInWords(std::string &file)
{
	std::ifstream infile;
	std::string line;
	std::string word;
	
	infile.open(file);
		if (infile.is_open()) {
			
			while (!infile.eof()) {
				getline(infile, line);
				//remove all puntucation from line
				line.erase(std::remove_if(line.begin(), line.end(), ispunct), line.end());
				//convert line to lowercase
				for (int i = 0; i < line.length(); i++) {
					line[i] = tolower(line[i]);
				}
				//split into words and insert to set
				std::stringstream spliter(line);
				while (spliter >> word) {
					doc.insert(word);
				}
			}
			std::cout << "File loaded...\n";
		}
		else {
			std::cout << "file not found. Please enter the file name with the \".txt\" at the end.\n";
		}
		infile.close();
	}

void Document::printSet()
{
	std::set<std::string>::iterator docIt;
	for (docIt = doc.begin(); docIt != doc.end(); docIt++) {
		std::cout << *docIt << " ";
	}
}
	
