﻿#include <cmath>
#include <string>
#include <set>
#include <algorithm>
#include "Document.h"
#include "Query.h"

using namespace std;

class Similarity {
private:
	double similar;
	std::set<std::string>combinedSets;
public: 
	
	double calcSimilarity(std::string&);

};

double Similarity::calcSimilarity(std::string &file)
{
	double simVal = 0.0;

	Document doc;
	Query que;


	doc.readInWords(file);
	que.readInWords();


	//Similarity = |Q∩D|/(sqrt(|Q|) *sqrt (|D|))
	std::set_intersection(doc.doc.begin(), doc.doc.end(), que.query.begin(), que.query.end(),
		std::inserter(this->combinedSets, combinedSets.begin()));

	simVal = combinedSets.size() / ((sqrt(que.getESize())) * sqrt(doc.getESize()));

	this->similar = simVal;
	return simVal;
}
