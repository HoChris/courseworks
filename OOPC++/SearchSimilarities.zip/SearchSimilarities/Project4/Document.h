#pragma once
#ifndef DOCUMENT_H
#define DOCUMENT_H

#include <iostream>
#include <fstream>
#include <set>
#include <string>
#include <algorithm>
#include <sstream>	
#include <iterator>	


using namespace std;
class Document {

public:
	std::set<std::string> doc;
	double getESize() { return doc.size(); };
	void readInWords(std::string& file);
	void printSet();
};
#endif // DOCUMENT_H

