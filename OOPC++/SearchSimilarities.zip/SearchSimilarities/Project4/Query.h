#pragma once
#ifndef QUERY_H
#define QUERY_H

#include <iostream>
#include "Document.h"

using namespace std;

class Query : public Document {

public:
	std::set<std::string> query;
	int getESize() { return query.size(); };
	void readInWords();
	void printSet();
};

#endif // !QUERY_H

