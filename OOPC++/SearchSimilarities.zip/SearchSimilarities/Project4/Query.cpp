#include <iostream>
#include "Document.h"

using namespace std;

class Query: public Document{

public:
	std::set<std::string> query;
	int getESize() { return query.size(); };
	void readInWords();
	void printSet();
};

void Query::readInWords()
{
	std::string line;
	std::string word;

	std::cout << "\nEnter a query (HIT enter then -1 to exit): ";
	
	while (std::getline(std::cin,line)) {
		if (line == "-1") break;
		//remove all puntucation from line
		line.erase(std::remove_if(line.begin(), line.end(), ispunct), line.end());
		//convert line to lowercase
		for (int i = 0; i < line.length(); i++) {
			line[i] = tolower(line[i]);
		}
		//split into words and insert to set
		std::stringstream spliter(line);
		while (spliter >> word) {
			query.insert(word);
		}
	}
}

void Query::printSet()
{
	std::set<std::string>::iterator queryIt;
	for (queryIt = query.begin(); queryIt != query.end(); queryIt++) {
		std::cout << *queryIt << " ";
	}
}
