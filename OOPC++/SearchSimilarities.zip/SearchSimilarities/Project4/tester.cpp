#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include "Document.h"
#include "Query.h"	
#include "Simialrity.h"
#include <iomanip>

using namespace std;

int main() {
	Similarity sim;

	std::string file;

	std::cout << "Please enter File name: ";
	std::cin >> file;
	sim.calcSimilarity(file);

	std::cout << "The similarity between the query and document is: " << std::setprecision(3) << sim.similar <<std::endl;

	//<--tests cow.txt-->
	//love holstein cows.....
	//LOvE HOsteIN CoWS
	//<--tests midsummer.txt-->
	//SCENE: Athens, and a wood not far from it. : 0.0541
	//juilet comes hither okay fine done time  :  0.0341
	//i IS a fine okay time TIME the :  0.0409
	/*With cunning hast thou filch'd my daughter's heart;
	Turned her obedience, which is due to me,
		To stubborn harshness.--And, my gracious duke,
		Be it so she will not here before your grace
		Consent to marry with Demetrius,
		I beg the ancient privilege of Athens, -- :  0.114 */
	return 0;
}