#pragma once
#ifndef SIMIALRITY_H
#define SIMIALRITY_H

#include <cmath>
#include <string>
#include <set>
#include <algorithm>
#include "Document.h"
#include "Query.h"

using namespace std;

class Similarity {

public:
	double similar;
	std::set<string>combinedSets;
	double calcSimilarity(std::string&);
	

};

#endif // !SEARCHSIM_H

