#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "ppmimage.h"

using namespace std;

void menu();

int main() {

	//PPMImage m;
	//
	//std::cout <<"Please Enter the (full)filename of the image: " << std::endl;
	//std::cin >> m;
	//std::cout << m;

	menu();

	return 0;
}

void menu()
{
	int select;
	PPMImage m;
	std::cin >> m;
	std::cout << "What would you like to do?\n"
		"	1.) Hide a message\n"
		"	2.) Recover a message\n"
		"	3.) Convert image to grayscale\n"
		"	4.) Convert image to sepia\n"
		"	5.) Convert image to negative\n"
		"	6.) Exit\n"
		"Enter your selection :";

	std::cin >> select;
	string msg;
	switch (select)
	{
	case 1:
		std::cin >> m;
		std::cout << "Please enter a phrase to hide : ";
		std::cin >> msg;
		hideData(msg, m);
		std::cout << "Your message \"" << msg << "\" has been hidden.\n";
		break;
	case 2: 
		std::cout << m;
		break;
	case 3:
		m.grayscale();
		std::cout << m;
		std::cout << "Been Grayscaled.\n";
		break;
	case 4:
		m.sepia();
		std::cout << m;
		std::cout << "Been Sepia'd.\n";
		break;
	case 5:
		m.negative();
		std::cout << m;
		std::cout << "Been negated.\n";
		break;
	case 6:
		std::cout << "Good Bye!\n";
		break;
	default:
		break;
	}


}
