#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

class PPMImage {
private:
	string magicNum;
	int width, height, maxColor;
	char *ptr_chars;
public:
	PPMImage();
	~PPMImage();
	friend const std::istream& operator >>(std::istream&, PPMImage&);
	friend const std::ostream& operator <<(const std::ostream&, const PPMImage&);
	friend void hideData(string& , PPMImage&);
	friend string recoverData(const PPMImage&);
	void PPMImage::grayscale();
	void PPMImage::sepia();
	void PPMImage::negative();
};

PPMImage::PPMImage()
{
	this->magicNum = "P6";
	this->width = 0;
	this->height = 0;
	this->maxColor = 255;
	this->ptr_chars = nullptr;
}

PPMImage::~PPMImage()
{
	delete[]ptr_chars;
	this->ptr_chars = nullptr;
}

void PPMImage::grayscale()
{
	const double R = .299;
	const double G = .587;
	const double B = .114;

	int size = this->width * this->height * 3;
	for (int i = 0; i < size; i+=3) {
		unsigned char gSV, red, green, blue;
		//cast rgb to unsigned char
		red = this->ptr_chars[i];
		green = this->ptr_chars[i + 1];
		blue = this->ptr_chars[i + 2];
		gSV = red * R + green * G + blue * B;
		//sets the new grayscale values.
		this->ptr_chars[i] = gSV;
		this->ptr_chars[i+1] = gSV;
		this->ptr_chars[i+2] = gSV;
		
	}
}

void PPMImage::sepia()
{

	int size = this->width * this->height * 3;
	for (int i = 0; i < size; i += 3) {
		unsigned char red, green, blue;
		unsigned int sred, sgreen, sblue;
		//cast rgb to unsigned int if max exceeds 255 set to 255
		red = this->ptr_chars[i];
		green = this->ptr_chars[i + 1];
		blue = this->ptr_chars[i + 2];
			//red
		sred = (red * .393) < 255 ? red * .393 : 255  +
			//green
			(green * .769) < 255 ? green * .769 : 255  +
			//blue
			(blue * .189) < 255 ? blue * .189 : 255 ;

		sgreen = (red * .349) < 255 ? red * .349 : 255 +
			(green * .686) < 255 ?  green * .686 : 255 +
			(blue * .168) < 255 ? blue * .168 : 255;

		sblue = (red * .272) < 255 ? red * .272 : 255 +
			(green * .534) < 255 ? green * .534 : 255 +
			(blue * .131) < 255 ? blue * .131 : 255 ;
		//sets the new rgb values.
		this->ptr_chars[i] = sred;
		this->ptr_chars[i + 1] = sgreen;
		this->ptr_chars[i + 2] = sblue;

	}
}

void PPMImage::negative()
{
		int size = this->width * this->height * 3;
		for (int i = 0; i < size; i += 3) {
			unsigned char red, green, blue;
			//cast rgb to unsigned int if less than 255 set to 0
			red =  this->maxColor - this->ptr_chars[i];
			green = this->maxColor - this->ptr_chars[i+1];
			blue = this->maxColor - this->ptr_chars[i+2];
			//sets the new negative values.
			this->ptr_chars[i] = red;
			this->ptr_chars[i + 1] = green;
			this->ptr_chars[i + 2] = blue;

		}
}

const std::istream & operator>>(std::istream &in, PPMImage &daImage)
{
	ifstream infile;
	string fileName;
	std::cout << "Please Enter the (full)filename of the image: " << std::endl;
	in >> fileName;

	infile.open(fileName, std::ifstream::binary);
	if (infile.fail()) { throw("Can't open Input file"); }
	infile >> daImage.magicNum >> daImage.width >>  daImage.height >> daImage.maxColor;
	infile.get();

	int memoryBlockSize = daImage.height * daImage.width * 3;
	daImage.ptr_chars = new char[memoryBlockSize];
	infile.read(daImage.ptr_chars, memoryBlockSize);

	return in;
}

const std::ostream & operator<<(const std::ostream &out, const PPMImage &daImage)
{
	ofstream outfile;
	string outfName;
	std::cout << "Please specify the output PPM filename: ";
	std::cin >> outfName;
	outfile.open(outfName, std::ofstream::binary);

	outfile << daImage.magicNum << "\n" 
		<< daImage.width << " " << daImage.height << "\n" 
		<< daImage.maxColor << "\n";
	int memoryBlockSize = daImage.height * daImage.width * 3;

	outfile.write(daImage.ptr_chars, memoryBlockSize);


	return out;
}

void hideData(string &msg , PPMImage& daImage)
{
	//have to convert char to unsigned
	//alter LSB for one letter is 8 bits or 1 byte
	//take each letter find the mask and turn on 1 or 0
	msg += '\0';
	int size = msg.size();

	for (int i = 0; i < msg.length(); i++) {
		unsigned char letter = msg[i];
		unsigned int num = letter;

		
		

		for (int j = 0; j < size; j += 3) {




		}

	}


}

string recoverData(const PPMImage &)
{
	return string();
}
