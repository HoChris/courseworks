#pragma once
#ifndef PPMIMAGE_H
#define PPMIMAGE_H

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

class PPMImage {
private:
	string magicNum;
	int width, height, maxColor;
	unsigned char *ptr_chars;
public:
	PPMImage();
	~PPMImage();
	friend const std::istream& operator >>(std::istream&, PPMImage&);
	friend const std::ostream& operator <<(const std::ostream&, const PPMImage&);
	friend void hideData(string&, PPMImage&);
	friend string recoverData(const PPMImage&);
	void PPMImage::grayscale();
	void PPMImage::sepia();
	void PPMImage::negative();
};
#endif // !PPMIMAGE_H

