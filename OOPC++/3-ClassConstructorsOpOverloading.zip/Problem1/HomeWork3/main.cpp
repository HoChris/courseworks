#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

class Weight {

public:
	Weight( );
	Weight(int pounds, int ounces);

	void output( ) const;
	void output_d( ) ;
	double convertOunces( );
	void setPounds(int pounds);
	void setOunces(int ounces);
	int getPounds( ) const;
	int getOunces( ) const;
	const Weight operator +(const Weight& weight2) const;
	const Weight operator -(const Weight& weight2) const;
	const Weight operator -( ) const;
	bool operator ==(const Weight& weight2) const;
private:
	int pounds;
	int ounces;
};


int main()
{
	Weight testweight(20, 17), testweight2(-5,16),
		testweight3(5,20),testweight4(5,-5),
		testweight5(-20,16), testweight6(8,45), result;
	std::cout << "display output" << endl;
	testweight.output_d();
	testweight.output();
	std::cout << "addition" << endl;
	result = (testweight + testweight2);
	result.output();
	result.output_d();
	std::cout << "subtration" << endl;
	result = (testweight4 - testweight5);
	result.output();
	result.output_d();
	std::cout << "negation" << endl;
	result = -testweight;
	result.output();
	result.output_d();
	result = -testweight5;
	result.output();
	result.output_d();
	return 0;
}
//default constructor
Weight::Weight( ): pounds(0), ounces(0){}
//Constructors w/ input
Weight::Weight(int pounds, int ounces) 
	:pounds(pounds), ounces(ounces) {
	//check if valid data
	/*if (pounds < 1) {
		std::cout << "Illegal pounds value!\n";
		exit(1);
	}
	
	if (ounces < 1) {
		std::cout << "Illegal ounces value!\n";
		exit(1);
	}*/

}
//prints pounds and ounces
void Weight::output() const
{
	std::cout << "The Weight is : " << getPounds() << " lb(s) " << getOunces() << " oz(s).\n";
}
//prints pounds only
void Weight::output_d()
{
	double totPounds = 0;
	totPounds = (double)getPounds( ) + convertOunces( );
	std::cout << "The Weight in Pounds : " << totPounds << " lb(s).\n";
}
//converts ounces to pounds 
double Weight::convertOunces()
{
	double ounceToPounds;
	 return ounceToPounds = getOunces() / 16.0;
}

//setters
void Weight::setPounds(int pounds)
{
	pounds = pounds;
}
void Weight::setOunces(int ounces)
{
	ounces = ounces;
}
//getters
int Weight::getPounds() const
{
	return pounds;
}
int Weight::getOunces() const
{
	return ounces;
}
//adding 2 objects
const Weight Weight::operator+(const Weight & weight2) const
{
	int totPounds = pounds + weight2.pounds;
	(totPounds < 0) ? totPounds = -totPounds : totPounds = totPounds;
	int totOunces = ounces + weight2.ounces;
	(totOunces < 0) ? totOunces = -totOunces : totOunces = totOunces;

	return Weight(totPounds, totOunces);
}
//subtracting 2 objects
const Weight Weight::operator-(const Weight & weight2) const
{
	int totPounds = pounds - weight2.pounds;
	(totPounds < 0) ? totPounds = -totPounds : totPounds = totPounds;
	int totOunces = ounces - weight2.ounces;
	(totOunces < 0) ? totOunces = -totOunces : totOunces = totOunces;

	return Weight(totPounds, totOunces);
}
//negative object
const Weight Weight::operator-( ) const
{
	return Weight(-pounds, -ounces);
}
//compairing 2 objects
bool Weight::operator==(const Weight & weight2) const
{
	return ((pounds == weight2.pounds) &&
		(ounces == weight2.ounces));
}

