#pragma once
#ifndef CIRCLE_H
#define CIRCLE_H

#include <cmath>
#include <iostream>
#include <string>
#include "Figure.h"

using namespace std;

class Circle : public Figure {
private:
	double radius;

public:
	void setRadius(double radius) { this->radius = radius; }
	double getRadius() { return this->radius; }
	double area();
	Circle( ) { area(); };
	Circle(double rad, std::string color) {
		this->radius = rad;
		this->color = color;
	}
};

#endif // !CIRCLE_H

