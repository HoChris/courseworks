#pragma once
#ifndef FIGURE_H
#define FIGURE_H

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

class Figure {
protected:
	std::string color;
public:
	void setColor(std::string nColor) { this->color = nColor; };
	std::string getColor() const { return this->color; };
	virtual double area() = 0;
	void print() {
		std::cout << "Area = " << area() << std::endl;
		std::cout << "Color = " << this->color << std::endl;
	};
	Figure() { this->color = "white"; };
	Figure(std::string nColor) { this->color = nColor; };
};
#endif // !FIGURE_H


