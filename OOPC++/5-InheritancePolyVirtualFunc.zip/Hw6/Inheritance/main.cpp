#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <ctime>
#include "Circle.h"
#include "Figure.h"
#include "Rectangle.h"

using namespace std;

double genRand( ) { return rand( ) % 30 + 1; };
int genRandColor() { return rand() % 9 ; };
const int COLOR_SIZE = 9;

int main() {
	srand( time(NULL) );

	std::string colors[COLOR_SIZE] = { "red" , "blue", "green", "purple",
		"cyan", "magenta", "yellow", "black", "apple" };
	std::vector<Figure*> shapes;
	std::vector<Figure*>::iterator big;

	for (int i = 0; i < 2; i++) {
		shapes.push_back(new Circle(genRand(), colors[genRandColor()]));
	}
	for (int j = 0; j < 3; j++) {
		shapes.push_back(new Rectangle(genRand(), genRand(), colors[genRandColor()]));
	}

	double max = shapes.front()->area();
	for (int i = 0; i < shapes.size(); i++) {
		std::cout << typeid(*shapes[i]).name() << std::endl;
		shapes[i]->print();
		if (max < shapes[i]->area()) {
			max = shapes[i]->area();
		}
		std::cout << std::endl;
	}
	std::cout << "The Largest Area is : " << max << std::endl;

	return 0;
}

