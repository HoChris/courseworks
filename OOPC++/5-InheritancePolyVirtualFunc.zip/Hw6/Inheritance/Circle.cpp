#include <cmath>
#include <iostream>
#include <string>
#include "Figure.h"

using namespace std;

class Circle : public Figure {
private:
	double radius;
	
public:
	void setRadius(double radius) { this->radius = radius; }
	double getRadius( ) { return this->radius; }
	double area();
	Circle() { area(); };
	Circle(double rad, std::string color) {
		this->radius = rad;
		this->color = color;
	}
};

double Circle::area()
{
	const double PI = 3.141592653589793;
	return  PI * (pow (this->radius,2));
}
