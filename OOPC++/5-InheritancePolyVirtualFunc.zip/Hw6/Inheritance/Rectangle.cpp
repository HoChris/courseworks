#include <iostream>
#include <cmath>
#include <string>
#include "Figure.h"

using namespace std;

class Rectangle : public Figure {
private:
	double w, h;
public:
	void setW(double width) { this->w = width; };
	void setH(double height) { this->h = height; };
	double getW( ) const { return this->w; };
	double getH( ) const { return this->h; };
	Rectangle() { this->w = 0.0; this->h = 0.0;};
	Rectangle(double width, double height, std::string nColor) {
		this->w = width;
		this->h = height;
		this->color = nColor;
	};
	double area();
};

double Rectangle::area()
{
	return getW() * getH();
}
