#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class MySet {
private:

	unsigned int *bitArray;
	int howBigArray;

public:

	MySet();
	MySet(std::vector<int>&);
	void displayBinary(int);
	int shiftMask(int);
	int findRange(int);
	int findMax(const std::vector<int>&);
	unsigned int getBitArray() { this->bitArray;};
	int getHowBigArray() { return this->howBigArray; };
	void insert(int, MySet&);
	void remove(int, MySet&);
	//operators
	friend std::ostream& operator <<(std::ostream& out , MySet toPrint);
	friend const MySet operator +(const MySet&, const MySet&);
	friend const MySet operator -(const MySet&, const MySet&);
	friend const MySet operator &(const MySet&, const MySet&);
	friend const bool operator == (const MySet&, const MySet&);

};

MySet::MySet()
{
	this->howBigArray = 1;
	this->bitArray = nullptr;
	this->bitArray = new unsigned int[howBigArray];
	bitArray[0] = 0;
	
}

MySet::MySet(std::vector<int> &daSet)
{
	this->bitArray = nullptr;
	this->howBigArray = findRange(findMax(daSet));
	this->bitArray = new unsigned int[howBigArray];
	//intialize array
	for (unsigned int i = 0; i < howBigArray; i++) { bitArray[i] = 0; }
	//builds the array of binary numbers
	for (unsigned int i = 0; i < daSet.size(); i++) {
		if (findRange(daSet[i]) == 0) {
			bitArray[0] |= shiftMask(daSet[i]);
		}
		else {
			bitArray[findRange(daSet[i]) - 1] |= shiftMask(daSet[i]);
		}
	}
}
//shows binary representation
void MySet::displayBinary(int x)
{
	unsigned int split = 0;
	std::cout << "the binary number of" << x << " is:";
	for (int i = 31; i >= 0; i--) {
		unsigned int shifted = x >> i;
		(shifted & 1) ? std::cout << "1" : std::cout << "0";
		split++;
		if (split == 8) { std::cout << " ";	split = 0; }
	}
	std::cout << std::endl;
}

int MySet::shiftMask(int val)
{
	unsigned int mask;
	unsigned int result;
		if (findRange(val) == 0) {
			 mask = 1 << (31 - val);
			 result = mask;
			 std::cout << "result from shifting : " << result << endl;
		}
		else {
			mask = 1 << (((findRange(val) * 32) - 1) - val);
			result = mask;
			std::cout << "result from shifting : " << result << endl;
		}

	return result;
}
//finds the max range for incoming value
int MySet::findRange(int val)
{
	unsigned int range = 0;
	range = val / 32;
	if (range == 0) { return range; }
	else { return range + 1; }
}
//find the max element in Set 
int MySet::findMax(const std::vector<int> &daSet)
{
	unsigned int val = 0;
	for (int i = 0; i < daSet.size(); i++) {
		(val < daSet[i]) ? val = daSet[i] : val = val;
	}
	return val;
}

void MySet::insert(int inVal, MySet &obj)
{
	if (obj.howBigArray < findRange(inVal)) {
		obj.bitArray = new unsigned int[findRange(inVal)];
		obj.bitArray[findRange(inVal) - 1] = 0;
	}

	if (findRange(inVal) == 0) {
		obj.bitArray[0] |= obj.shiftMask(inVal);
	}
	else {
		obj.bitArray[findRange(inVal) - 1] |= obj.shiftMask(inVal);
	}
}

void MySet::remove(int delVal, MySet &obj)
{
	if (findRange(delVal) == 0) {
		obj.bitArray[0] |= ~(obj.shiftMask(delVal));
	}
	else {
		obj.bitArray[findRange(delVal) - 1] |= ~(obj.shiftMask(delVal));
	}
}

std::ostream & operator<<(std::ostream & out, MySet toPrint)
{
	
	for (int i = 0; i < toPrint.howBigArray; i++) {
		out << "the binary number " << toPrint.bitArray[i] << " is: ";
		int split = 0;
		for (int j = 31; j >= 0; j--) {
			int shifted = toPrint.bitArray[i] >> j;
			(shifted & 1) ? out << "1" : out << "0";
			split++;
			if (split == 8) { out << " ";	split = 0; }
		}
		out << std::endl;
	}
	return out;
}

const MySet operator+(const MySet &lhs, const MySet &rhs)
{
	MySet added;
	added.bitArray = nullptr;
	(lhs.howBigArray > rhs.howBigArray) ? 
		added.howBigArray = lhs.howBigArray : added.howBigArray = rhs.howBigArray;
	added.bitArray = new unsigned int[added.howBigArray];
	//initialize array
	for (int i = 0; i < added.howBigArray; i++) { added.bitArray[i] = 0; }
	//pop added values
	for (unsigned int i = 0; i < added.howBigArray; i++) {
		(lhs.bitArray[i] != rhs.bitArray[i]) ? 
			added.bitArray[i] = rhs.bitArray[i] : added.bitArray[i] = lhs.bitArray[i];
	}
	return added;
}

const MySet operator-(const MySet &lhs, const MySet &rhs)
{
	MySet complemented;

	complemented.bitArray = nullptr;
	(lhs.howBigArray > rhs.howBigArray) ?
		complemented.howBigArray = lhs.howBigArray : complemented.howBigArray = rhs.howBigArray;
	complemented.bitArray = new unsigned int[complemented.howBigArray];
	//initialize array
	for (int i = 0; i < complemented.howBigArray; i++) { complemented.bitArray[i] = 0; }
	//pop complemtend array
	for (int i = 0; i < complemented.howBigArray; i++) {
		(lhs.bitArray[i] != rhs.bitArray[i]) ?
			complemented.bitArray[i] = lhs.bitArray[i] : complemented.bitArray[i] = 0;
	}
	return complemented;
}

const MySet operator&(const MySet &lhs, const MySet &rhs)
{
	MySet intersected;

	intersected.bitArray = nullptr;
	(lhs.howBigArray > rhs.howBigArray) ?
		intersected.howBigArray = lhs.howBigArray : intersected.howBigArray = rhs.howBigArray;
	intersected.bitArray = new unsigned int[intersected.howBigArray];
	//initialize array
	for (int i = 0; i < intersected.howBigArray; i++) { intersected.bitArray[i] = 0; }
	//pop complemtend array
	for (int i = 0; i < intersected.howBigArray; i++) {
		(lhs.bitArray[i] == rhs.bitArray[i]) ?
			intersected.bitArray[i] = lhs.bitArray[i] : intersected.bitArray[i] = 0;
	}
	return intersected;
}

const bool operator == (const MySet &lhs, const MySet &rhs)
{
	bool isSame = false;
	int leftSize = lhs.howBigArray;
	int rightSize = rhs.howBigArray;
	if (leftSize == rightSize) {
		for (int i = 0; i < lhs.howBigArray; i++) {
			if (lhs.bitArray[i] == rhs.bitArray[i]) { isSame = true; }
			else { return isSame = false; }
		}
	}
	return isSame;
}
