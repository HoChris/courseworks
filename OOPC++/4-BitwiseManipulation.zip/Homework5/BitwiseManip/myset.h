#pragma once
#ifndef MYSET_H
#define MYSET_H

#include <iostream>
#include <vector>

using namespace std;

class MySet {
private:

	unsigned int *bitArray;
	int howBigArray;

public:

	MySet();
	MySet(std::vector<int>&);
	void displayBinary(int);
	int shiftMask(int);
	int findRange(int);
	int findMax(const std::vector<int>&);
	unsigned int getBitArray() { this->bitArray; };
	int getHowBigArray() { return this->howBigArray; };
	void insert(int, MySet&);
	void remove(int, MySet&);
	//operators
	friend std::ostream& operator <<(std::ostream& out, MySet toPrint);
	friend const MySet operator +(const MySet&, const MySet&);
	friend const MySet operator -(const MySet&, const MySet&);
	friend const MySet operator &(const MySet&, const MySet&);
	friend const bool operator == (const MySet&, const MySet&);

};
#endif // !MYSET_H
