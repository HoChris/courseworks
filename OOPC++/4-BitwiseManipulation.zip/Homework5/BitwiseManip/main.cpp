#include <iostream>
#include <cstdlib>
#include <vector>
#include "myset.h"

//https://www.youtube.com/watch?v=Cq1h1KPoGBU vevtor tut
using namespace std;

void displayBinary(unsigned int);

int main()
{
	vector<int> myVector;
	

	myVector.push_back(3);
	myVector.push_back(27);
	myVector.push_back(100);
	myVector.push_back(33);
	myVector.push_back(50);
	MySet m(myVector);
	MySet m2(myVector);
	//displayBinary(myVector.at(0));

	int mask = 1 << (31 - 3);
	int result = mask;
	
	displayBinary(result);
	mask = 1 << (31 - 27);
	result |= mask;
	displayBinary(result);

	std::cout << "\nFrom the vector: \n";

	std::cout << m << endl;
	std::cout << "Are they the same: ";
	(m == m2) ? std::cout << "true" :
		std::cout << "false"; std::cout << std::endl;
	MySet m3 = m + m2;
	std::cout << "The Unioned result \n" << m3;
	m3 = m - m2;
	std::cout << "The complemented result \n" << m3;
	m3 = m & m2;
	std::cout << "The Intersected result \n" << m3;
	MySet m4;
	m4.insert(99,m4);
	std::cout << m4;
	return 0;
}
void displayBinary(unsigned int x)
{
	int split = 0;
	std::cout << "the binary number of " << x << " is: ";
	for (int i = 31; i >= 0; i--) {
			int var = x >> i;
			if (var & 1) { std::cout << "1"; }
			else { std::cout << "0"; }
			split++;
			if (split == 8) {
				std::cout << " ";
				split = 0;
			}
	}
	std::cout << std::endl;
}