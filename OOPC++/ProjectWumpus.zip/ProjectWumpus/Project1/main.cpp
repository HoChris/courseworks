#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <Windows.h>

using namespace std;

class Bats {
public:
	Bats() {};
	void setBat();
	int getBRP() const { return bRowPos; }
	int getBCP() const { return bColPos; }
private:
	int bRowPos = 0;
	int bColPos = 0;
};
class Pitfalls {
public:
	Pitfalls() {};
	void setPit();
	int getPitRP() const { return pitRowPos; }
	int getPitCP() const { return pitColPos; }
private:
	int pitRowPos = 0;
	int pitColPos = 0;
};
class Wumpus {
public:
	Wumpus() {};
	void setWumpus();
	void moveWumpus();
	int getWRP() const { return wRowPos; }
	int getWCP() const { return wColPos; }
private:
	int wRowPos = 0;
	int wColPos = 0;
	bool isAlive = true;
};
class Player {
public:
	Player() {};
	void setPlayer();
	void setPRP(int x) { pRowPos = x; }
	void setPCP(int x) { pColPos = x; }
	void setArrowCount(int);
	int getPRP() const { return pRowPos; }
	int getPCP() const { return pColPos; }
	int getArrCount() const { return arrowCount; }
private:
	int pRowPos = 0;
	int pColPos = 0;
	int arrowCount = 3;
	bool isAlive = true;
	bool HasArrows = true;
};
class Arrows {
public:
	Arrows() {};
	void setArrow();
	int getARP() const { return arrRowPos; }
	int getACP() const { return arrColPos; }
private:
	int arrRowPos = 0;
	int arrColPos = 0;
};

const int ROWS = 9;
const int COLS = 9;
const char PLAYER = '@';
const char WUMPUS = 'W';
const char BAT = 'B';
const char ARROW = '>';
const char PIT = '0';
bool debug = false;

void loadingSymb();
char makeBoard(char [][COLS], Bats, Bats, Wumpus, Pitfalls, Pitfalls, Arrows, Arrows, Player*);
void menu(Player, char [][COLS], Bats , Bats , Wumpus , Pitfalls , Pitfalls , Arrows , Arrows );
void moveMenu(Player&, char[][COLS], Bats, Bats, Wumpus, Pitfalls, Pitfalls, Arrows, Arrows);
bool isAdjacent(Player, char[][COLS]);
void printBoard(char [][COLS], Player, Bats , Bats , Wumpus , Pitfalls , Pitfalls , Arrows , Arrows);
void checkAround(Player*, char[][COLS]);
void printLegend();
void ClearScreen();


int randGenPlace();

int main() {
	//loadingSymb();
	srand(unsigned(time(NULL)));
	Player player;
	Wumpus wumpus;
	Bats bat1, bat2;
	Arrows arr1, arr2;
	Pitfalls pit1, pit2;

	player.setPlayer();
	bat1.setBat();
	bat2.setBat();
	wumpus.setWumpus();
	pit1.setPit();
	pit2.setPit();
	arr1.setArrow();
	arr2.setArrow();

	char huntBoard[ROWS][COLS];
	makeBoard(huntBoard, bat1, bat2, wumpus, pit1, pit2, arr1, arr2, &player);
	printBoard(huntBoard, player,bat1, bat2, wumpus, pit1, pit2, arr1, arr2);
	std::cout << "Hello Player. Are you ready to defeat the Wumpus? Or is it the\n other way around...\n";
	printLegend();
	menu(player, huntBoard, bat1, bat2, wumpus, pit1, pit2, arr1, arr2);
	return 0;
}
void loadingSymb() {
	
	std::cout << "Loading  " << std::flush;
	for (int i = 0; i < 18;i++) {
		Sleep(90);
		std::cout << "\b\\" << std::flush;
		Sleep(90);
		std::cout << "\b|" << std::flush;
		Sleep(90);
		std::cout << "\b/" << std::flush;
		Sleep(90);
		std::cout << "\b-" << std::flush;
	}
	std::cout << "\b\b\b\b\b\b\b\b\b" << std::flush;
}

char makeBoard(char arr[][COLS], Bats b1, Bats b2, Wumpus w, Pitfalls pit1, Pitfalls pit2, Arrows arr1, Arrows arr2, Player* p)
{	
	//fill board
	for (int x = 0; x < ROWS; x++) {
		for (int y = 0; y < COLS; y++) {
		
			if (arr[x][y] == arr[b1.getBRP()][b1.getBCP()] || arr[x][y] == arr[b2.getBRP()][b2.getBCP()]) {
				arr[x][y] = BAT;
			}
			else if (arr[x][y] == arr[pit1.getPitRP()][pit1.getPitCP()] || arr[x][y] == arr[pit2.getPitRP()][pit2.getPitCP()]) {
				arr[x][y] = PIT;
			}
			else if (arr[x][y] == arr[arr1.getARP()][arr1.getACP()] || arr[x][y] == arr[arr2.getARP()][arr2.getACP()]) {
				arr[x][y] = ARROW;
			}
			else if (arr[x][y] == arr[w.getWRP()][w.getWCP()]) {
				arr[x][y] = WUMPUS;
			}
			arr[x][y] = (char)177;
		}
	}
	//walls
	for(int x = 0; x < ROWS; x++) {
		for (int y = 0; y < COLS; y++) {
			if (arr[0][y] || arr[ROWS-1][y]) {
				arr[0][y] = (char)223;
				arr[ROWS-1][y] = (char)220;
			}
			if(arr[x][0] || arr[x][COLS-1]) {
				arr[x][0] = (char)221;
				arr[x][COLS-1] = (char)222;
			}
		}
	}

	return arr[ROWS][COLS];
}

void menu(Player p, char board[][COLS], Bats b1, Bats b2, Wumpus w, Pitfalls pit1, Pitfalls pit2, Arrows arr1, Arrows arr2)
{
	char gameOptions = NULL;
	//options
	do {
		if (debug == true) {
			std::cout << "Debug mode Active!\n\n";
		}
		std::cout << "Press \t1:Move \t2:Shoot\n \t3:Save \tq:Quit\n \tg:Debug \n\n";
		std::cin >> gameOptions;
		tolower(gameOptions);
		switch (gameOptions) {
			//move
		case '1':
			moveMenu(p, board, b1, b2, w, pit1, pit2, arr1, arr2);
			break;
			//shoot
		case '2':; break;
			//save
		case '3':; break;
			//quit
		case 'q':
			std::cout << "Exiting. Have a nice day.\n\n";
			exit(1);
			break;
			//debug
		case 'g':
			debug = true;
			printBoard(board, p, b1, b2, w, pit1, pit2, arr1, arr2);
			menu(p, board, b1, b2, w, pit1, pit2, arr1, arr2);
			break;
		}
	} while (gameOptions != 'q');
}

void moveMenu(Player &p, char board[][COLS], Bats b1, Bats b2, Wumpus w, Pitfalls pit1, Pitfalls pit2, Arrows arr1, Arrows arr2)
{
	bool keepMoving = false;
	char action = NULL;
	//movement
	do {
		makeBoard(board, b1, b2, w, pit1, pit2, arr1, arr2, &p);
		checkAround(&p, board);
		std::cout << "Press to move w: Up a: Left s: Down D: Right \n\n";
		std::cin >> action;
		tolower(action);
		if(action == 'w'|| action == 'a' || action == 's' || action == 'd'){
			if (isalpha(action)) {
				switch (action) {
					//up
				case 'w':
					if (board[p.getPRP() - 1][p.getPCP()] == (char)223) {
						std::cout << "Cant move up anymore..\n";
					}
					else {
						board[p.getPRP()][p.getPCP()] = '-';
						p.setPRP(p.getPRP() - 1);
				
					}
					break;
					//left
				case 'a':
					if (board[p.getPRP()][p.getPCP() - 1] == (char)221) {
						std::cout << "Cant move Left anymore..\n";
					}
					else {
						board[p.getPRP()][p.getPCP()] = '-';
						p.setPCP(p.getPCP() - 1);
					
					}
					break;
					//down
				case 's':
					if (board[p.getPRP() + 1][p.getPCP()] == (char)220) {
						std::cout << "Cant move down anymore..\n";
					}
					else {
						board[p.getPRP()][p.getPCP()] = '-';
						p.setPRP(p.getPRP() + 1);
					
					}
					break;
					//right
				case 'd':
					if (board[p.getPRP()][p.getPCP() + 1] == (char)222) {
						std::cout << "Cant move Right anymore..\n";
					}
					else {
						board[p.getPRP()][p.getPCP()] = '-';
						p.setPCP(p.getPCP() + 1);
						
					}
					break;
				}
			}
			else {
				std::cout << "Please enter the Correct letter....\n";
				keepMoving = true;
			}
			ClearScreen();
			printBoard(board, p, b1, b2, w, pit1, pit2, arr1, arr2);
			while (1){
				std::cout << "Keep moving? y = yes n = no : ";
				std::cin >> action;
		
			
				if (action == 'n' || action == 'y') {
					(action == 'n') ? keepMoving = false : keepMoving = true;
					break;
				}
				else {
					std::cout << "Didnt enter a correct letter.. " << endl;
				}
			}
		}
		else {
			std::cout << "Didnt enter a letter.." << endl;
			keepMoving = true;
		}
	} while (keepMoving != false);
	menu(p, board, b1, b2, w, pit1, pit2, arr1, arr2);
}

bool isAdjacent(Player p, char board[][COLS])
{
	bool isClose = false;
	int posX = p.getPRP();
	int posY = p.getPCP();

	//if object is up
	if (BAT == board[posX - 1][posY]) {
		std::cout << "You hear flapping nearby" << endl;
		isClose = true;
	}
	else if (WUMPUS == board[posX - 1][posY]) {
		std::cout << "You smell a foul stench nearby." << endl;
		isClose = true;
	}
	else if(PIT == board[posX - 1][posY]){
		std::cout << "You feel a breeze nearby." << endl;
		isClose = true;
	}
	//else {
	//	std::cout << "Proceed Onward!" << endl;
	//	isClose = false;
	//}
	//if object is down
	else if (BAT == board[posX + 1][posY]) {
		std::cout << "You hear flapping nearby" << endl;
		isClose = true;
	}
	else if (WUMPUS == board[posX - 1][posY]) {
		std::cout << "You smell a foul stench nearby." << endl;
		isClose = true;
	}
	else if (PIT == board[posX + 1][posY]) {
		std::cout << "You feel a breeze nearby." << endl;
		isClose = true;
	}
	//else {
	//	std::cout << "Proceed Onward!" << endl;
	//	isClose = false;
	//}
	//if object is left
	else if (BAT == board[posX - 1][posY]) {
		std::cout << "You hear flapping nearby" << endl;
		isClose = true;
	}
	else if (WUMPUS == board[posX][posY - 1]) {
		std::cout << "You smell a foul stench nearby." << endl;
		isClose = true;
	}
	else if (PIT == board[posX][posY - 1]) {
		std::cout << "You feel a breeze nearby." << endl;
		isClose = true;
	}
	//else {
	//	std::cout << "Proceed Onward!" << endl;
	//	isClose = false;
	//}
	//if object is right
	else if (BAT == board[posX][posY + 1]) {
		std::cout << "You hear flapping nearby" << endl;
		isClose = true;
	}
	else if (WUMPUS == board[posX - 1][posY]) {
		std::cout << "You smell a foul stench nearby." << endl;
		isClose = true;
	}
	else if (PIT == board[posX][posY + 1]) {
		std::cout << "You feel a breeze nearby." << endl;
		isClose = true;
	}
	else {
		std::cout << "Proceed Onward!" << endl;
		isClose = false;
	}
	return isClose;
}

void printBoard(char arr[][COLS], Player p, Bats b1, Bats b2, Wumpus w, Pitfalls pit1, Pitfalls pit2, Arrows arr1, Arrows arr2)
{
	for (int x = 0; x < ROWS; x++) {
		for (int y = 0; y < COLS; y++) {
			if (x == p.getPRP() && y == p.getPCP()) {
				std::cout << " " << PLAYER << " ";
			}
			else {
				std::cout << " " << arr[x][y] << " ";
			}
		}
		std::cout << endl << endl;
	}
	//show true map
	if (debug == true) {
		for (int x = 0; x < ROWS; x++) {
			for (int y = 0; y < COLS; y++) {
				if (x == p.getPRP() && y == p.getPCP()) {
					std::cout << " " << PLAYER << " ";
				}
				else if (x == b1.getBRP() && y == b1.getBCP()) {
					std::cout << " " << BAT << " ";
				}
				else if (x == b2.getBRP() && y == b2.getBCP()) {
					std::cout << " " << BAT << " ";
				}
				else if (x == w.getWRP() && y == w.getWCP()) {
					std::cout << " " << WUMPUS << " ";
				}
				else if (x == pit1.getPitRP() && y == pit1.getPitCP()) {
					std::cout << " " << PIT << " ";
				}
				else if (x == pit2.getPitRP() && y == pit2.getPitCP()) {
					std::cout << " " << PIT << " ";
				}
				else if (x == arr1.getARP() && y == arr1.getACP()) {
					std::cout << " " << ARROW << " ";
				}
				 else if (x == arr2.getARP() && y == arr2.getACP()) {
					std::cout << " " << ARROW << " ";
				}
				else {
					std::cout << " " << arr[x][y] << " ";
				}
			}
			std::cout << endl << endl;
		}
	}

}

void checkAround(Player *p, char board[][COLS])
{
	isAdjacent(*p,board);
}

void printLegend()
{
	std::cout << "-----------------------------\n";
	std::cout << "\tPlayer : @ \tWumpus : W \n \tBat : B \tArrow : > \n \tPitFall : 0 \n";
	std::cout << "-----------------------------\n";
}

void ClearScreen()
{
	for (int i = 0; i < 10; i++) {
		std::cout << "\n\n\n\n\n";
	}
}

int randGenPlace()
{
	return rand() % 7 + 1;
}

void Player::setPlayer()
{
	pRowPos = randGenPlace();
	pColPos = randGenPlace();
}

void Arrows::setArrow()
{
	arrRowPos = randGenPlace();
	arrColPos = randGenPlace();
}

void Bats::setBat()
{
	bRowPos = randGenPlace();
	bColPos = randGenPlace();
}

void Pitfalls::setPit()
{
	pitRowPos = randGenPlace();
	pitColPos = randGenPlace();
}

void Wumpus::setWumpus()
{
	wRowPos = randGenPlace();
	wColPos = randGenPlace();
}
