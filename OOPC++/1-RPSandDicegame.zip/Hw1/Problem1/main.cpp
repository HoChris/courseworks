#include <iostream>
#include <cmath>
#include <cstdlib>

using namespace std;

void estHeight(int, double, double);

int main() {
	int x = 0;
	int y = 0;
	double mom = 0;
	double dad = 0;
	do {
		std::cout << "Please enter the gender of the Child\n"
			"Press 0 for Female or 1 for Male " << endl;
		std::cin >> x;
		std::cout << "Enter the Height of the Mother in INCHES: " << endl;
		std::cin >> mom;
		std::cout << "Enter the Height of the Father in INCHES: " << endl;
		std::cin >> dad;
		estHeight(x, mom, dad);
		std::cout << "Hit 5 to quit out. Otherwise hit 1 to Continue.\n";
		std::cin >> y;
	} while (y != 5);

	return 0;
}

void estHeight(int x, double m, double d) {
	double childHeight;
	if ((x >= 1) ? false : true) {
		childHeight = ((d*(12. / 13)) + m)/2;
		std::cout << "The female height is : " << (double)childHeight << " inches.\n";
	}
	else {
		childHeight = ((m*(13 / 12)) + d)/2;
		std::cout << "The male height is : " << (double)childHeight << " inches.\n";
	}
}