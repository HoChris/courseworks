#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

int compPick();
void whatIs(int);
void whoWin(int, int);
//1 = rock, 2 = paper, 3 = scissors 
// 
int main() {
	int playerPick = 0;
	int whatComp = compPick();

	std::cout << "Rock, Paper, Scissors game Versus the Computer.\n"
				"Choose 1 = rock || 2 = paper || 3 = scissors \n" ;
	std::cin >> playerPick;
	std::cout << "Player Picks: "; whatIs(playerPick);
	std::cout << " and the Computer Picks:"; whatIs(whatComp);
	whoWin(playerPick, whatComp);

	return 0;
}

int compPick() {
	srand(time(NULL));
	return rand()%3 + 1;
}
void whoWin(int pChoice, int cChoice) {
	
	if (pChoice >= 3 && cChoice == 2) {
//3 beats 2
		std::cout << "Player Scissors cuts Computer Paper\n."
					"Player Wins.\n";
	}
	else if(pChoice == 2 && cChoice == 1){
//2 beats 1
		std::cout << "Player Paper wraps Computer Rock\n."
					"Player Wins.\n";
	}
	else if (pChoice == 1 && cChoice >= 3) {
		std::cout << "Player Rock smashes Computer Scissors.\n"
					"Player Wins.\n";
	}
	else if (cChoice >= 3 && pChoice == 2) {
		//3 beats 2
		std::cout << "Compuer Scissors cuts Player Paper\n."
				"Computer Wins.\n";
	}
	else if (cChoice == 2 && pChoice == 1) {
		//2 beats 1
		std::cout << "Computer Paper wraps Player Rock\n."
				"Computer Wins.\n";
	}
	else if (cChoice == 1 && pChoice >= 3) {
		std::cout << "Computer Rock smashes Player Scissors.\n"
				"Computer Wins.\n";
	}
	else {
		std::cout << "Its a tie." << endl;
	}

}
void whatIs(int x) {
	switch (x) {
	case 1:
		std::cout << " Rock " << endl;
		break;
	case 2:
		std::cout << " Paper " << endl;
		break;
	case 3:
		std::cout << " Scissor " << endl;
		break;
	}
}