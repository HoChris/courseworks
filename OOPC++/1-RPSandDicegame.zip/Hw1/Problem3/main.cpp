#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;
int rollDice();
int compPoints();
int playerPoints(bool);
int playerTot = 0;
int compTot = 0;
void whoWin(int, int);
bool endGame;

// 2 player game first player to reach 100 point wins
int main() {
	srand(time(NULL));
	bool choice;
	

	do {
		std::cout << "Player to Roll Dice Hit 0 to Roll Or Hit 1 to Hold.\n\n";
		std::cin >> choice; 
		playerPoints(choice);
		compPoints();
		whoWin(playerTot, compTot);

	} while (endGame != true);
	
	return 0;
}

int playerPoints(bool roll) {
	if (roll == false) {
		while (playerTot <= 100) {
			if (rollDice() != 1) {
				playerTot += rollDice();
			}
			else {
				std::cout << playerTot << " is the current points.\n\n";
				break;
			}
		}
	}
	else {
		std::cout << playerTot << " is the total number of point you have.\n"
			"Now its the computers Turn.\n\n";

	}
	return playerTot;
}
int compPoints() {
	while (compTot <=20) {
		if (rollDice() != 1) {
			compTot += rollDice();
		}
		else {
			break;
		}
	}
	compTot += rollDice();
	std::cout << compTot << " is the computer number of points. Player Turn.\n"
		<< "Player you have: " << playerTot << endl << endl;
	
	return compTot;
}
void whoWin(int pScore, int cScore) {
	if (pScore >= 100) {
		endGame = true;
		std::cout << "Player you WIN!!!\n.";
	}
	else if (cScore >=100) {
		endGame = true;
		std::cout << "Computer becomes Skynet!!!\n.";
	}
	else {
		std::cout << "Its a close game.......\n";
	}
}
int rollDice() {
	return rand() % 6 + 1;

}