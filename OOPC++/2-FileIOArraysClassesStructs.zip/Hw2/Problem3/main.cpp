/*Define a struct Point3D having x, y, z of type int. Each Point3D represents a point location in
3D. Write a program which:
� creates an array of Point3D storing 7 elements the data for the points should be populated from a
file called "points_data.txt". The format of this file will be integers listed 3 numbers per line with
each line representing x, y, and z for one point respectively.
� translate the positions of each point by a given amount and display the result (this step does not modify
the original array).
� reflect the positions of each point about one of the planes, either xy, yz , or xz (user choice) and display
the result (this step does not modify the original array).
� Your program should have translate() and reflect() functions to change each point.
? translate needs to know the amount to translate by (user input)
? reflect needs to know which plane to reflect the points (user input)
� the formula for translate is : x'=x+t, y'=y+t, and z'=z+t, where t is the translation amount.
� the formula for reflection is:
? xy-plane is given by x'=x, y'=y, z=-z'.
? yz-plane is given by x'=-x, y'=y, z=z'.
? xz-plane is given by x'=x, y'=-y, z=z'.*/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;
enum THE_AXIES { xy = 1, yz, xz };

struct Point3D {

	int x = 0;
	int y = 0;
	int z = 0;

};

const int ARRAY_SIZE = 7;

void popArray(Point3D []);
void translate(Point3D []);
void reflect(Point3D []);
void printPoints(Point3D []);

int main() 
{

	Point3D thePoints[ARRAY_SIZE];
	popArray(thePoints);
	printPoints(thePoints);
	translate(thePoints);
	reflect(thePoints);
	

	return 0;
}
void popArray(Point3D arr[])
{
	int number = 0;
	std::ifstream inStream("points_data.txt");
	if (inStream.is_open())
	{
			while (!inStream.eof())
			{
				for (int i = 0; i < ARRAY_SIZE; i++)
				{
					inStream >> arr[i].x >> arr[i].y >> arr[i].z;
				}
			}
	}
	else 
	{
		inStream.fail();
		cout << "file not found." << endl;
		exit(1);
	}
	inStream.close();
}


void translate(Point3D arr[])
{
	int trans = 0;
	int choice = 0;
	//the formula for translate is : x'=x+t, y' = y + t, and z'=z+t, where t is the translation amount.
	std::cout << "Which Axies you want to Translate the Points about \n" <<
		"|| for XY press 1 || for YZ press 2 || for XZ press 3 \n\n||:";
	std::cin >> choice;
	std::cout << "How much do you want points to translate by \n||:";
	std::cin >> trans;
	Point3D temp[ARRAY_SIZE];
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		temp[i] = arr[i];
	}
	switch (choice)
	{
	case xy: 
		for (int i = 0; i < ARRAY_SIZE; i++)
		{
			temp[i].x = temp[i].x + trans;
			temp[i].y = temp[i].y + trans;
		}

		std::cout << "	Here are the Translated Points about XY axies \n\n";
		printPoints(temp);
		break;
	case yz:
		for (int i = 0; i < ARRAY_SIZE; i++) 
		{
			temp[i].y = temp[i].y + trans;
			temp[i].z = temp[i].z + trans;
		}

		std::cout << "	Here are the Translated Points about YZ axies \n\n";
		printPoints(temp);
		break;
	case xz:
		for (int i = 0; i < ARRAY_SIZE; i++)
		{
			temp[i].x = temp[i].x + trans;
			temp[i].z = temp[i].z + trans;
		}


		std::cout << "	Here are the Translated Points about XZ axies \n\n";
		printPoints(temp);
		break;
	}
}

void reflect(Point3D arr[])
{

	int choice = 0;

	std::cout << "Which Axies you want to Reflect the Points about \n" <<
		"|| for XY press 1 || for YZ press 2 || for XZ press 3 \n\n||:";
	std::cin >> choice;
	
	Point3D temp[ARRAY_SIZE];
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		temp[i] = arr[i];
	}
	
	switch (choice)
	{
	case xy:
		for (int i = 0; i < ARRAY_SIZE; i++)
		{
			if (temp[i].z < 0)
			{
				temp[i].z = abs(temp[i].z);
			}
			else
			{
				temp[i].z = -abs(temp[i].z);
			}
			
		}

		std::cout << "	Here are the Reflected Points about XY axies \n\n";
		printPoints(temp);
		break;
	case yz:
		for (int i = 0; i < ARRAY_SIZE; i++)
		{
			if (temp[i].x < 0)
			{
				temp[i].x = abs(temp[i].x);
			}
			else
			{
				temp[i].x = -abs(temp[i].x);
			}

		}

		std::cout << "	Here are the Reflected Points about XY axies \n\n";
		printPoints(temp);
		break;
	case xz:
		for (int i = 0; i < ARRAY_SIZE; i++)
		{
			if (temp[i].y < 0)
			{
				temp[i].y = abs(temp[i].y);
			}
			else
			{
				temp[i].y = -abs(temp[i].y);
			}

		}

		std::cout << "	Here are the Reflected Points about XY axies \n\n";
		printPoints(temp);
		break;
	}

}
void printPoints(Point3D arr[])
{
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		printf("Point %d: X: %d Y:%d Z:%d \n", i+1, arr[i].x, arr[i].y, arr[i].z);
	}
	std::cout << "\n\n";

}