#include <iostream>	
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

const int PIN_SIZE = 5;
const int ARRAY_SIZE = 10;

void storePin(int[], const int);
void zeroOut(int[]);
void genRandomPin(int[], const int);
void printRandomPin(int[]);
void printPinDigits(int[]);
void enterMatch(int[], const int);
bool isCorrect(int[], int[], int[], int[], const int, const int);
void rightWrong(bool);


int main() {
	srand((unsigned)time(NULL));

	int zeroNums[ARRAY_SIZE];
	int thePinNumber[PIN_SIZE];
	int randomNum[ARRAY_SIZE];
	int matchinPin[PIN_SIZE];

	zeroOut(thePinNumber);
	storePin(thePinNumber, PIN_SIZE);
	
	zeroOut(randomNum);
	zeroOut(zeroNums);
	printPinDigits(zeroNums);
	/*for (int i = 0; i < ARRAY_SIZE; i++) {
		std::cout << zeroNums[i] << " ";
	}*/

	genRandomPin(randomNum, ARRAY_SIZE);
	printRandomPin(randomNum);

	zeroOut(matchinPin);
	enterMatch(matchinPin, PIN_SIZE);
	rightWrong(isCorrect(thePinNumber, zeroNums, 
		matchinPin, randomNum, ARRAY_SIZE, PIN_SIZE));
	return 0;
}

void zeroOut(int arr[]) {
	for (int i = 0; i < PIN_SIZE; i++) {
		arr[i] = 0;
	}
}

void storePin(int arr[], const int PIN_SIZE) {
	bool flag = false;

	int x;
	std::cout << "(space between each individual PIN number 0-9, Hit Enter when done.)\n";
	std::cout << "Please enter the 5 digit PIN number you want to store.\n||:";
	
	for (int i = 0; i < PIN_SIZE; i++) {
		std::cin >> x;
		(x < 10) ? arr[i] = x : flag = true; 

	}
	if (flag == true) {
		std::cout << "Please select Numbers 0-9 Please.\n";
		storePin(arr, PIN_SIZE);
	}
	std::cout << "\n\n\n";
}
void genRandomPin(int arr[], const int ARRAY_SIZE) {

	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		arr[i] = rand() % 3 + 1;
	}
}
void printRandomPin(int arr[]) {
	std::cout << "NUM: ";
	for (int i = 0; i < ARRAY_SIZE; i++) {
		std::cout << arr[i] << " ";
	}
	std::cout << "\n";
}
void printPinDigits(int arr[]) {

	std::cout << "PIN: ";
	for (int i = 0; i < ARRAY_SIZE; i++) {
		arr[i] = i;
		std::cout << arr[i] << " ";
	}
	std::cout << "\n";
}


void enterMatch(int arr[], const int PIN_SIZE) {

	bool flag = false;
	int x = 0;

	std::cout << "(space between each individual PIN number 1-3, Hit Enter when done.)\n";
	std::cout << "Please enter your 5 digit PIN number using NUM numbers.\n||:";
	
	for (int i = 0; i < PIN_SIZE; i++) {
		std::cin >> x;
		(x <= 3 && x > 0) ? arr[i] = x : flag = true;

	}
	if (flag == true) {
		std::cout << "Please select Numbers 1-3 Please.\n";
		enterMatch(arr, PIN_SIZE);
	}
	std::cout << "\n\n\n";

}

bool isCorrect(int pin [], int digits[], int randMatch[],int genNumber[], const int ARRAY_SIZE, const int PIN_SIZE)
{
	bool flag = false;
	int doesItMatch[5];
	int count = 0;
	zeroOut(doesItMatch);

	/*for (int i = 0; i < ARRAY_SIZE; i++) {
		std::cout << digits[i] << " ";
	}*/

	//set only pin numbers
	for (int i = 0; i < ARRAY_SIZE; i++) {
		if (pin[i] == digits[i]) {
			digits[i] = digits[i];
		}
		else {
			for (int j = i; j < ARRAY_SIZE; j++) {
				if (pin[i] == digits[j]) {
					digits[j] = digits[j];
				}
				else {
					digits[j] = 0;
				}
			}
		}
	}
	//sets regular numbers to the gentrate numbers
	for (int i = 0; i < ARRAY_SIZE; i++) {
		(digits[i] != 0) ? digits[i] = genNumber[i] : digits[i] = 0;
	}
	//put digit into new array pin size
	for (int i = 0; i < ARRAY_SIZE; i++) {
		if (digits[i] != 0) {
			doesItMatch[count] = digits[i];
		}
	}

	
	std::cout << "\n";
	for (int i = 0; i < PIN_SIZE; i++) {
		std::cout << doesItMatch[i] << " ";
	}
	std::cout << "\n";
	for (int i = 0; i < PIN_SIZE; i++) {
		std::cout << pin[i] << " ";
	}
	std::cout << "\n";

	for (int i = 0; i < PIN_SIZE; i++) {
		if (randMatch[i] == doesItMatch[i]) {
			flag == true;
		}
		else {
			flag == false;
			break;
		}
	}

	return flag;
}

void rightWrong(bool)
{
	if (true) {
		std::cout << "You've enter the correct PIN!.\n";
	}
	else {
		std::cout << "The PIN does not MATCH, DESTORYING EVERYTHING....\n";
	}
	

}
