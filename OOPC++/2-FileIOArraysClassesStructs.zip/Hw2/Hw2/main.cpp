#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

const int A_SIZE = 7; 

int arrayOfNum[A_SIZE];

void menuOptions(int printMenu);
void printOG();
int printMenu();
void genArray();
void shift(int[],int);
void replaceNums(int[]);
void evenFront(int[]);
bool isSorted(int[]);
bool isDup(int[]);
bool isThreeDup(int[]);

/*
Move all even elements to the front, otherwise preserving the order of the elements.
*/

int main() {
	
	srand((unsigned)time(NULL));
	genArray();

	menuOptions(printMenu());

	return 0;
}

int printMenu() {

	int playerChoice = 0;
	std::cout << "	Please Select one of the following to manipulate Array: \n\n"
		"	1 -- Shift Array number of spaces to the left.	\n"
		"	2 -- 1st and last number are same, rest are changed to large adjacent. \n"
		"	3 -- Move all even number to frontend of array. \n"
		"	4 -- Is the Array sorted smallest to largest? \n"
		"	5 -- Are there 3 of the same number adjacent? \n"
		"	6 -- Is there more than one of the same number in Array? \n";
	
	std::cin >> playerChoice;
	std::cout << "\n\n";

	return playerChoice;
}

void menuOptions(int printMenu) {
	
	enum menuChoices {SHIFT = 1, LARGE_ADJACENT, EVEN, SORTED, THREE_PAIR, DUPLICATE};
	int numberShift = 0;

	switch (printMenu) {

	case SHIFT: 
		std::cout << "	Picked Shift: Enter number of shifts." << endl;
		std::cin >> numberShift;
		shift(arrayOfNum, numberShift);
		break;

	case LARGE_ADJACENT:
		replaceNums(arrayOfNum);
		break;

	case EVEN:
		evenFront(arrayOfNum);
		break;

	case SORTED:
		printOG();
		if (isSorted(arrayOfNum) == true) {
			std::cout << "\n	True.\n";
		}
		else {
			std::cout << "\n	False.\n";
		}
		break;

	case THREE_PAIR:
		printOG();
		if (isThreeDup(arrayOfNum) == true) {
			std::cout << "\n	True.\n";
		}
		else {
			std::cout << "\n	False.\n";
		}
		break;

	case DUPLICATE:
		printOG();
		if (isDup(arrayOfNum) == true) {
			std::cout << "\n	True.\n";
		}
		else {
			std::cout << "\n	False.\n";
		}
		break;
	}
}
void printOG()
{
	//OG array
	std::cout << "	OG Array" << endl;

	for (int i = 0; i < A_SIZE; i++) {
		std::cout << arrayOfNum[i] << " ";
	}
}
void genArray() {

	for (int i = 0; i < A_SIZE; i++) {
		arrayOfNum[i] = 0;
	}

	for (int i = 0; i < A_SIZE; i++) {
		arrayOfNum[i] = rand() % 20 + 1;
	}
}
void shift(int arr[], int shifted) {

	int shiftArry[A_SIZE];
	int count = 0;

	printOG();

	//shift to left
	for (int i = 0; i < A_SIZE; i++) {
		
		shiftArry[i] = arrayOfNum[i];
		arrayOfNum[i] = arrayOfNum[i + shifted];
		if (arrayOfNum[i] == 0) {
			arrayOfNum[i] = shiftArry[count];
			count++;
		}
		
	}
	//print shifted array
	std::cout << "\n	Shifted " << shifted << " spaces to the left. \n";
	for (int i = 0; i < A_SIZE; i++) {
		std::cout << arrayOfNum[i] << " ";
	}
	std::cout << endl;
}

void replaceNums(int arr[] )
{
	int temp[A_SIZE];

	printOG();
	//zeroed
	for (int i = 0; i < A_SIZE; i++) {
		temp[i] = 0;
	}
	//copy array 
	for (int i = 0; i < A_SIZE; i++) {
		temp[i] = arr[i];
	}
	//
	for (int i = 1; i < A_SIZE - 2; i++) {
		//left
		if (temp[i] < arr[i - 1]) {
			temp[i] = arr[i - 1];
		}
		else if (temp[i] > arr[i - 1]) {
			temp[i];
		}
		//right
		if (temp[i] < arr[i + 1]) {
			temp[i] = arr[i + 1];
		}
		else if (temp[i] > arr[i + 1]) {
			temp[i];
		}
	}

	std::cout << "\n	New Array\n";
	for (int i = 0; i < A_SIZE; i++) {
		std::cout << temp[i] << " ";
	}
	std::cout << endl;

}

void evenFront(int arr[])
{
	int count = 0;
	printOG();
	//swaping evens to front 
	for (int i = 0; i < A_SIZE; i++) {
		if (arr[i] % 2 == 0) {

			for (int j = i; j > count; j--) {
				int holder = arr[j - 1];
				arr[j - 1] = arr[j];
				arr[j] = holder;
			}
			count++;
		}
	}
	// print 
	std::cout << "\n	New Array\n";
	for (int i = 0; i < A_SIZE; i++) {
		std::cout << arr[i] << " ";
	}
	std::cout << endl;

}

bool isSorted(int arr[])
{
	for (int i = 0; i < A_SIZE; i++) {
		if (arrayOfNum[i] <= arrayOfNum[i + 1]) {
			true;
		}
		else {
			break;
		}
	}
	return false;
}

bool isDup(int arr[])
{
	bool flag = false;
	for (int i = 0; i < A_SIZE; i++) {
		int  temp = arrayOfNum[ i ];
		for (int j = i+1; j < A_SIZE; j++) {
			if (temp == arrayOfNum[j]) {
				flag = true;
				return flag;
			}
		}
	}
	return flag;
}

bool isThreeDup(int arr[])
{
	bool flag = false;

	for (int i = 0; i < A_SIZE; i++) {
		int temp = arrayOfNum[i];
		if (temp == arrayOfNum[i + 1]) {
			if (temp == arrayOfNum[i + 2]) {
				flag = true;
				return flag;
			}
		}
	}
	return flag;
}

