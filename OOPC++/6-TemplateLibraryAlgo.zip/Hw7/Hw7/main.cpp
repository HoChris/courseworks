#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

void popGrades(std::vector<int>&);
void prtMsg();
int counter(int totGrade = 0 ) { return totGrade++; }

int main() {
	int grade = 0;
	int totGrade = 0;
	std::vector<int> inputGrades;
	std::map<int, int> grades;

	prtMsg();

	while (grade != -1) {
		std::cin >> grade;
		inputGrades.push_back(grade);
	}
	// 3 0 1 3 3 5 5 4 5 -1
	// 10 10 9 2 3 4 5 6 8 8 8 8 8 8 8 8 8 -1
	// 1 1 1 1 9 9 11 15 7 7 2 8 9 -1

	popGrades(inputGrades);

	return 0;
}

void popGrades(std::vector<int> &inputGrades)
{
	//pop map with 0's
	std::map<int, int> grades;
	for (int i = 0; i < inputGrades.size(); i++) {
		grades[i] = 0;
	}
	std::map<int, int>::iterator g;
	//inputs the grade with the frequency
	for (int x : inputGrades) {
		grades[x] = count(inputGrades.begin(), inputGrades.end(), x);
	}
	//sets map iterator to max value
	g = grades.find( *std::max_element(inputGrades.begin(), inputGrades.end()) + 1);
	//erases to left over 0's and shrinks to map size 
	grades.erase(g, grades.end());
	//print the map only till the max value of the vector
	for (g = grades.begin(); g != grades.end(); g++) {
		if (g->first != -1) {
			std::cout << g->second << " grade(s) of " << g->first << std::endl;
		}
	}
}

void prtMsg()
{
	std::cout << "Please enter student Grades, enter -1 to close input.\n";
}
