package DaShapes;

public class ShapeList extends DeArrayList {

	public Shape3D maxVolume(){
	
	}
	public Shape3D minVolume(){
		
	}
	public void displayCylinders(){
		return toString();
	}
	public void displayPyramids(){
		return toString();
	}
	public double averageAreaOfAll(){
		for(int i = 0; i<getListShapes(),i++){
					
			int j += getListShapes(i);
		}
		return j;
			
	}
	public double averageAreaOfCylinders(){
		
	}
	public double averageAreaOfPyramids(){
		
	}
}
