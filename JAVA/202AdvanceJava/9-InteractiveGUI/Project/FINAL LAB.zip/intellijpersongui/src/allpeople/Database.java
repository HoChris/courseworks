package allpeople;

import java.util.ArrayList;


/**
 * The Class {@code Database} main functionality is to organize the 
 * incoming arraylist of person objects into specific arraylist to later 
 * be displayed by the GUI. Main points are showing the database, 
 * showing specific types of objects, and quantity of objects.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Database {
	
	/** The some people holds the objects in an
	 * arraylist . */
	private ArrayList<Person> somePeople;
	
	/** The temp is a temporary arraylist used to store certain person objects
	 * that have been sorted through methods. */
	private ArrayList<Person> temp;
	
	/** The temp2 is a temporary arraylist used to store certain Integer objects
	 * that have been sorted through methods. */
	private ArrayList<String>temp2;

	/**
	 * Instantiates a new database.
	 *
	 * @param inPeople the in people
	 */
	public Database(ArrayList<Person> inPeople) {
		this.somePeople = inPeople;
	}

	/**
	 * Prints the entire database.
	 */
	public void printDatabase() {
		System.out.println("\t\tEntire Database");
		for (Person x : somePeople) {
			System.out.println("\n---------------------");
			System.out.println(x.toString());
		}
	}

	/**
	 * Prints the database to the specified type of person
	 * object.
	 *
	 * @param inType the type the users specified
	 */
	public void printDatabase(String inType) {
		for (Person x : somePeople) {
			if (x instanceof Faculty && x.obType().equalsIgnoreCase(inType)) {
				System.out.println("\n--------------------- Faculty");
				System.out.println(x.toString());
			} else if (x instanceof Staff
					&& x.obType().equalsIgnoreCase(inType)) {
				System.out.println("\n--------------------- Staff");
				System.out.println(x.toString());
			} else if (x instanceof Student
					&& x.obType().equalsIgnoreCase(inType)) {
				System.out.println("\n--------------------- Student");
				System.out.println(x.toString());
			} else if (x instanceof Employee
					&& x.obType().equalsIgnoreCase(inType)) {
				System.out.println("\n--------------------- Employee");
				System.out.println(x.toString());
			} else if (x instanceof Person
					&& x.obType().equalsIgnoreCase(inType)) {
				System.out
						.println("\n--------------------- Non Contributing members to Society");
				System.out.println(x.toString());
			}
		}// end foreach
	}
	//for GUI ONLY
	/**
	 * Sets {@code temp} arraylist to the specified type of object
	 * determined by the GUI.
	 *
	 * @param inType the type user specifies
	 * @return the array list
	 */
	public ArrayList<Person> setTypeDatabase(String inType) {
		temp = new ArrayList<Person>();
		for (Person x : somePeople) {
			if (x instanceof Faculty && x.obType().equalsIgnoreCase(inType)) {
				temp.add(x);
			} else if (x instanceof Staff
					&& x.obType().equalsIgnoreCase(inType)) {
				temp.add(x);
			} else if (x instanceof Student
					&& x.obType().equalsIgnoreCase(inType)) {
				temp.add(x);
			} else if (x instanceof Employee
					&& x.obType().equalsIgnoreCase(inType)) {
				temp.add(x);
			} else if (x instanceof Person
					&& x.obType().equalsIgnoreCase(inType)) {
				temp.add(x);
			}
		}// end foreach
		return temp;
	}

	/**
	 * Gets the number of students by class standing.
	 *
	 * @param inType the type the user specifies
	 * @return the number of students by class standing
	 */
	public int getNumberofStudensByClassStanding(String inType) {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Student
					&& ((Student) x).getClassStand().equalsIgnoreCase(inType)) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Displays {@code Employee} with a greater than salary of $30,000.
	 */
	public void displayEmployyesGreaterThanSalary() {
		for (Person x : somePeople) {
			if (x instanceof Employee && ((Employee) x).getSalary() > 30000) {
				System.out.println("\n------------Greater Than 30k");
				System.out.println(x.toString());
			}
		}
	}

	//FOR GUI ONLY
	/**
	 * Sets {@code temp} arraylist to store person
	 * objects by the amount salary.
	 *
	 * @param inType the type the user specifies
	 * @return the array list
	 */
	public ArrayList<Person> setOrderSalary (String inType){
		temp = new ArrayList<Person>();
		for (Person x : somePeople){
			if(inType.equalsIgnoreCase(">")){
				if (x instanceof Employee && ((Employee) x).getSalary() > 30000) {
					temp.add(x);
				}
			}
			else if(inType.equalsIgnoreCase("==")){
				if (x instanceof Employee && ((Employee) x).getSalary() == 30000) {
					temp.add(x);
				}
			}
			else if (inType.equalsIgnoreCase("<")){
				if (x instanceof Employee && ((Employee) x).getSalary() < 30000) {
					temp.add(x);
				}
			}
		}
		return temp;
	}

	/**
	 * Display {@code Employee} with an equal to salary of $30,000.
	 */
	public void displayEmployyesEqualToSalary() {
		for (Person x : somePeople) {
			if (x instanceof Employee && ((Employee) x).getSalary() == 30000) {
				System.out.println("\n------------Equal To 30k");
				System.out.println(x.toString());
			}
		}
	}

	/**
	 * Display {@code Employee} with a lesser than salary of $30,000. 
	 */
	public void displayEmployyesLesserThanSalary() {
		for (Person x : somePeople) {
			if (x instanceof Employee && ((Employee) x).getSalary() < 30000) {
				System.out.println("\n------------Lesser Than 30k");
				System.out.println(x.toString());
			}
		}
	}

	// numbers of types
	/**
	 * Gets the number of people in the database.
	 *
	 * @return the number of people
	 */
	public int getNumberofPeople() {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Person && x.obType().equalsIgnoreCase("person"))
				count++;
		}
		return count;
	}

	/**
	 * Gets the number of students in the database.
	 *
	 * @return the number of students
	 */
	public int getNumberofStudents() {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Student && x.obType().equalsIgnoreCase("student")) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Gets the number of employees in the database.
	 *
	 * @return the number of employees
	 */
	public int getNumberofEmployees() {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Employee
					&& x.obType().equalsIgnoreCase("employee")) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Gets the number of staff in the database.
	 *
	 * @return the number of staff
	 */
	public int getNumberofStaff() {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Staff && x.obType().equalsIgnoreCase("staff")) {
				count++;
			}
		}
		return count;
	}

	/**
	 * Gets the number of faculty in the database.
	 *
	 * @return the number of faculty
	 */
	public int getNumberofFaculty() {
		int count = 0;
		for (Person x : somePeople) {
			if (x instanceof Faculty && x.obType().equalsIgnoreCase("faculty")) {
				count++;
			}
		}
		return count;
	}
	//FOR GUI ONLY
	/**
	 * Sets {@code temp2} arraylist of the quantity of the specified type 
	 * objects .
	 *
	 * @param countType the count type
	 * @return the array list
	 */
	public ArrayList<String>setNumberCount(String countType){
		int count = 0;
		temp2 = new ArrayList<String>();
		for (Person x : somePeople) {
			if (x instanceof Person && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
			else if (x instanceof Employee && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
			else if (x instanceof Faculty && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
			else if (x instanceof Staff && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
			else if (x instanceof Student && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
			else if (x instanceof Student && x.obType().equalsIgnoreCase(countType)) {
				count++;
			}
		}//end for
		temp2.add(String.valueOf(count));
		return temp2;
	}



	/**
	 * Gets the temporary arraylist.
	 *
	 * @return the temporary arraylist
	 */
	public ArrayList<Person> getTemp() {
		return temp;
	}

	/**
	 * Gets the temp2 arraylist.
	 *
	 * @return the temp2 temporary arraylist.
	 */
	public ArrayList<String> getTemp2() {
		return temp2;
	}

	/**
	 * Sets the some people arraylist.
	 *
	 * @param somePeople the new some people
	 */
	public void setSomePeople(ArrayList<Person> somePeople) {
		this.somePeople = somePeople;
	}
}
