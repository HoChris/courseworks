package allpeople;

import java.util.ArrayList;


/**
 * The Class {@code PhoneNumber} stores the Phone number(s) 
 * for each person. The phone number consist of the type of phone number
 * be it a Cell , Work, Home phone number then the actual digits.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class PhoneNumber {
	
	/** The type refers to what kind of phone number it is
	 * for example a cell number, or work number. */
	private String type;
	
	/** The suffix the last 4 digits in the number. */
	private int areaCode, prefix, suffix;
	
	/** The filled list stores the number(s) into an arraylist. */
	private ArrayList<PhoneNumber> filledList;
	
	/** The string data phone stores the number(s) as {@code String}
	 * into an arraylist. */
	private ArrayList<String>stringDataPhone;
	
	/** The incoming phone a phonenumber in {@code String} form. */
	private String incomingPhone;


	/**
	 * Instantiates a new phone number.
	 *
	 * @param type the type
	 * @param areaCode the area code
	 * @param prefix the prefix
	 * @param suffix the suffix
	 */
	public PhoneNumber(String type, int areaCode, int prefix, int suffix) {
		this.type = type;
		this.areaCode = areaCode;
		this.prefix = prefix;
		this.suffix = suffix;
		filledList = new ArrayList<PhoneNumber>();// saves phone to arraylist
		filledList.add(this);

	}

	// no arg constructor
	/**
	 * Instantiates a new phone number.
	 */
	public PhoneNumber() {
		this.type = "blank";
		this.areaCode = 123;
		this.prefix = 321;
		this.suffix = 5467;
		filledList = new ArrayList<PhoneNumber>();
		filledList.add(this);
		stringDataPhone = new ArrayList<String>();
		String daPhone = String.format("%s : %d-%d-%d",
				this.type,
				this.areaCode,
				this.prefix,
				this.suffix);
		stringDataPhone.add(daPhone);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String phones;
		phones = type + ": (" + areaCode + ") " + prefix + "-" + suffix;
		return phones;
	}

	/*@Override
	public String toString() {
		String phones="";
		for(PhoneNumber x : filledList) {
			phones += type + ": (" + areaCode + ") " + prefix + "-" + suffix;
			if(filledList.indexOf(x)<filledList.size()-1){
				phones+="\n";
			}
		}
		return phones;
	}*/
	//getters
	/**
	 * Gets the filled list.
	 *
	 * @return the filled list
	 */
	public ArrayList<PhoneNumber> getFilledList() {
		return filledList;
	}

	/**
	 * Gets the suffix.
	 *
	 * @return the suffix
	 */
	public int getSuffix() {
		return suffix;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Gets the area code.
	 *
	 * @return the area code
	 */
	public int getAreaCode() {
		return areaCode;
	}

	/**
	 * Gets the prefix.
	 *
	 * @return the prefix
	 */
	public int getPrefix() {
		return prefix;
	}

	/**
	 * Gets the string data phone.
	 *
	 * @return the string data phone
	 */
	public ArrayList<String> getStringDataPhone(){
		return stringDataPhone;
	}
	
	/**
	 * Gets the incoming phone.
	 *
	 * @return the incoming phone
	 */
	public String getIncomingPhone(){
		return incomingPhone;
	}
	// setters
	/**
	 * Sets the area code.
	 *
	 * @param areaCode the new area code
	 */
	public void setAreaCode(int areaCode) {
		this.areaCode = areaCode;
	}

	/**
	 * Sets the filled list.
	 *
	 * @param filledList the new filled list
	 */
	public void setFilledList(ArrayList<PhoneNumber> filledList) {
		this.filledList = filledList;
	}

	/**
	 * Sets the prefix.
	 *
	 * @param prefix the new prefix
	 */
	public void setPrefix(int prefix) {
		this.prefix = prefix;
	}

	/**
	 * Sets the suffix.
	 *
	 * @param suffix the new suffix
	 */
	public void setSuffix(int suffix) {
		this.suffix = suffix;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Sets the string data phone.
	 *
	 * @param stringDataPhone the new string data phone
	 */
	public void setStringDataPhone(ArrayList<String> stringDataPhone) {
		this.stringDataPhone = stringDataPhone;
	}

	/**
	 * Sets the incoming phone.
	 *
	 * @param incomingPhone the new incoming phone
	 */
	public void setIncomingPhone(String incomingPhone) {
		this.incomingPhone = incomingPhone;
	}
}
