package allpeople;

import java.util.ArrayList;


/**
 * The Class {@code Person} stores a person first and last name, email address,
 * any phonenumbers that are assigned, and the address.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Person {
	
	/** The first name, last name and email. */
	private String firstName, lastName, email;
	
	/** pnum is the list of numbers that belong to the person. */
	private ArrayList<PhoneNumber> pNum;
	
	/** The list phones is the phone numbers just stored as 
	 * {@code String} . */
	private ArrayList<String> listPhones;
	
	/** The phone a single object of class {@code PhoneNumber}. */
	private PhoneNumber phone;
	
	/** The address object of class {@code Address}. */
	private Address address;

	// takes and arraylist of phones
	/**
	 * Instantiates a new person.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param pNum the phone numbers
	 * @param address the address
	 */
	public Person(String firstName, String lastName, String email,
			ArrayList<PhoneNumber> pNum, Address address) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.pNum = pNum;
		this.address = address;
	}

	// takes PhoneNumber object
	/**
	 * Instantiates a new person.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param address the address
	 * @param phone the phone
	 */
	public Person(String firstName, String lastName, String email,
			Address address, PhoneNumber phone) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.pNum = phone.getFilledList();
		this.address = address;
	}

	// no-arg constructor
	/**
	 * Instantiates a new person.
	 */
	public Person() {
		this.firstName = "blank";
		this.lastName = "blank";
		this.email = "blank";
		this.pNum = new ArrayList<PhoneNumber>();
		this.listPhones = new ArrayList<String>();
		this.phone = new PhoneNumber();
		this.pNum.add(this.phone);
		this.address = new Address();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String printInfo;
		printInfo = "\nName:\t\t\t\t " + firstName + " " + lastName
				+ "\nEmail:\t\t\t\t " + email + "\nAddress:\t\t\t " + address
				+ "Phone Number(s):                 ";
		for (PhoneNumber x : pNum) {
			printInfo += x.toString();
			if(pNum.indexOf(x)<pNum.size()-1){
				printInfo+="\n";
			}
			printInfo += "\t\t\t\t ";
		}
		return printInfo;
	}
	

	/**
	 * Ob type is used to set the Object type Name to be latter referenced. For example 
	 * the object type name of a {@code Person} is person,
	 * the object type name of a {@code Employee} is employee.
	 *
	 * @return the string
	 */
	public String obType() {
		return "Person";
	}


	// Getters

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * Gets the p num.
	 *
	 * @return the p num
	 */
	public ArrayList<PhoneNumber> getpNum() {
		return pNum;
	}

	/**
	 * Gets the list phones.
	 *
	 * @return the list phones
	 */
	public ArrayList<String> getListPhones(){return  listPhones;}

	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public PhoneNumber getPhone() {
		return phone;
	}

	// setters
	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Sets the pnum arraylist of Phone number(s).
	 *
	 * @param pNum the new pnum arraylist of Phone number(s)
	 */
	public void setpNum(ArrayList<PhoneNumber> pNum) {
		this.pNum = pNum;
	}

	/**
	 * Sets the phone.
	 *
	 * @param phone the new phone
	 */
	public void setPhone(PhoneNumber phone) {
		this.phone = phone;
	}

	/**
	 * Sets the list phones.
	 *
	 * @param listPhones the new list phones
	 */
	public void setListPhones(ArrayList<String> listPhones) {
		this.listPhones = listPhones;
	}
}
