package allpeople;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The Class {@code FileReader} is used to read in a .csv filetype
 * and sort the data into specific {@code Person} objects. After the 
 * sorting is complete it returns the arraylist populated with {@code Person}
 * and {@code PhoneNumber} objects.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class FileReader extends ArrayList<Person> {
	
	/** da people is the arraylist that is used to store the person
	 * objects while the method runs. */
	private ArrayList<Person> daPeople;
	
	/** The da phones is the arraylist that is used to store the Phone Number
	 * objects while the method runs. */
	private ArrayList<PhoneNumber> daPhones;
	
	/** The done list is the arraylist that is used to duplicate the person
	 * objects. */
	private ArrayList<Person> doneList;
	
	/** The phone stringlist is the arraylist that is used to store the Phone number
	 * in a {@code String} form while the method runs. */
	private ArrayList<String>phoneStringlist;

	/**
	 * Instantiates a new file reader.
	 */
	public FileReader() {
		this.daPeople = new ArrayList<Person>();
		File daFile = new File("testdata1.csv");
		sortObj(daFile);
	}

	/**
	 * Instantiates a new file reader.
	 *
	 * @param inFile the users absolute path to the .csv file.
	 */
	public FileReader(String inFile) {
		this.daPeople = new ArrayList<Person>();
		File daFile = new File(inFile);
		sortObj(daFile);
	}

	/**
	 * Instantiates a new file reader.
	 *
	 * @param file the file passed in by the GUI
	 */
	public FileReader(File file) {
		this.daPeople = new ArrayList<Person>();
		sortObj(file);
	}

	/**
	 * Sort object method is used to sort out the .cvs file and assign the data
	 * to the right datafields through setter methods of the necessary classes.
	 * The process is to read in one line at a time using the {@code Scanner} class and splitting the line 
	 * into {@code tokens}. The tokens are used to set the data into the specific
	 *  class then added to the {@code daPeople},{@code daPeople},{@code daPeople}
	 *  ,{@code daPeople} arraylists.
	 *
	 * @param file the file provided by the user
	 */
	public void sortObj(File file) {

		try {
			Scanner reader = new Scanner(file);
			phoneStringlist = new ArrayList<>();
			daPhones = new ArrayList<PhoneNumber>();
			doneList = new ArrayList<Person>(); // to save new list with phones added
			while (reader.hasNext()) {
				String daLine = reader.nextLine();
				String[] tokens = daLine.split(",");
				if (tokens[0].equalsIgnoreCase("phonenumber")) {
					PhoneNumber z = new PhoneNumber();
					z.setType(tokens[1]);
					z.setAreaCode(Integer.parseInt(tokens[2]));
					z.setPrefix(Integer.parseInt(tokens[3]));
					z.setSuffix(Integer.parseInt(tokens[4]));
					daPhones.add(z);
					z.setIncomingPhone(z.toString());
					daPeople.get(daPeople.size() - 1).setpNum(daPhones);
					daPeople.get(daPeople.size() - 1).setListPhones(phoneStringlist);
					z.setFilledList(daPhones);
				} else if (tokens[0].equalsIgnoreCase("faculty")) {
					daPhones = new ArrayList<>();// intializes list
					Faculty p = new Faculty();
					p.setFirstName(tokens[1]);
					p.setLastName(tokens[2]);
					p.setEmail(tokens[9]);
					Address address = new Address();
					address.setStreetNum(Integer.parseInt(tokens[3]));
					address.setAptNum(Integer.parseInt(tokens[4]));
					address.setStreetName(tokens[5]);
					address.setCity(tokens[6]);
					address.setState(tokens[7]);
					address.setZipCode(Integer.parseInt(tokens[8]));
					p.setAddress(address);
					p.setSalary(Double.parseDouble(tokens[10]));
					p.setOffice(tokens[11]);
					p.setOffHrs(tokens[12]);
					p.setRank(tokens[13]);
					daPeople.add(p);
				} else if (tokens[0].equalsIgnoreCase("staff")) {
					daPhones = new ArrayList<>();
					Staff p = new Staff();
					p.setFirstName(tokens[1]);
					p.setLastName(tokens[2]);
					p.setEmail(tokens[9]);
					Address address = new Address();
					address.setStreetNum(Integer.parseInt(tokens[3]));
					address.setAptNum(Integer.parseInt(tokens[4]));
					address.setStreetName(tokens[5]);
					address.setCity(tokens[6]);
					address.setState(tokens[7]);
					address.setZipCode(Integer.parseInt(tokens[8]));
					p.setAddress(address);
					p.setSalary(Double.parseDouble(tokens[10]));
					p.setOffice(tokens[11]);
					p.setJobTitle(tokens[12]);
					daPeople.add(p);
				} else if (tokens[0].equalsIgnoreCase("employee")) {
					daPhones = new ArrayList<>();
					Employee p = new Employee();
					p.setFirstName(tokens[1]);
					p.setLastName(tokens[2]);
					p.setEmail(tokens[9]);
					Address address = new Address();
					address.setStreetNum(Integer.parseInt(tokens[3]));
					address.setAptNum(Integer.parseInt(tokens[4]));
					address.setStreetName(tokens[5]);
					address.setCity(tokens[6]);
					address.setState(tokens[7]);
					address.setZipCode(Integer.parseInt(tokens[8]));
					p.setAddress(address);
					p.setSalary(Double.parseDouble(tokens[10]));
					p.setOffice(tokens[11]);
					daPeople.add(p);
				} else if (tokens[0].equalsIgnoreCase("student")) {
					daPhones = new ArrayList<>();
					Student p = new Student();
					p.setFirstName(tokens[1]);
					p.setLastName(tokens[2]);
					p.setEmail(tokens[9]);
					Address address = new Address();
					address.setStreetNum(Integer.parseInt(tokens[3]));
					address.setAptNum(Integer.parseInt(tokens[4]));
					address.setStreetName(tokens[5]);
					address.setCity(tokens[6]);
					address.setState(tokens[7]);
					address.setZipCode(Integer.parseInt(tokens[8]));
					p.setAddress(address);
					p.setClassStand(tokens[10]);
					daPeople.add(p);
				} else if (tokens[0].equalsIgnoreCase("person")) {
					daPhones = new ArrayList<>();
					Person p = new Person();
					p.setFirstName(tokens[1]);
					p.setLastName(tokens[2]);
					p.setEmail(tokens[9]);
					Address address = new Address();
					address.setStreetNum(Integer.parseInt(tokens[3]));
					address.setAptNum(Integer.parseInt(tokens[4]));
					address.setStreetName(tokens[5]);
					address.setCity(tokens[6]);
					address.setState(tokens[7]);
					address.setZipCode(Integer.parseInt(tokens[8]));
					p.setAddress(address);
					daPeople.add(p);
				}

			}// end while
			this.doneList = daPeople;
			reader.close();
		}// end of Try
		catch (FileNotFoundException ex) {
			System.out.println("File not found. Please input correct path...");
		}
	}// end sort

	// getter
	/**
	 * Gets the da people arraylist.
	 *
	 * @return the da people
	 */
	public ArrayList<Person> getDaPeople() {
		return this.daPeople;
	}

	/**
	 * Gets the da phones arraylist.
	 *
	 * @return the da phones
	 */
	public ArrayList<PhoneNumber> getDaPhones() {
		return daPhones;
	}

	/**
	 * Gets the done list arraylist.
	 *
	 * @return the done list
	 */
	public ArrayList<Person> getDoneList() {
		return doneList;
	}
}
