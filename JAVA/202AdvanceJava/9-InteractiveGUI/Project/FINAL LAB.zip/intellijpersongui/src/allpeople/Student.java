package allpeople;

import java.util.ArrayList;

/**
 * The class {@code Student} is a subclass from the {@code Person} class
 * thus inherits the parameters from super class. This class adds the
 * parameter of what type of Class standing status they are assigned.
 * Example if the status is Freshman, Sophomore, Junior, Senior, Graduate.
 *
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Student extends Person {
	
	/** The class stand status. */
	private String classStand;

	/**
	 * Instantiates a new student.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param pNum the phone numbers 
	 * @param address the address
	 * @param classStand the class stand
	 */
	public Student(String firstName, String lastName, String email,
			ArrayList<PhoneNumber> pNum, Address address, String classStand) {
		super(firstName, lastName, email, pNum, address);
		this.classStand = classStand;
	}

	/**
	 * Instantiates a new student.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param address the address
	 * @param phone the phone
	 * @param classStand the class stand
	 */
	public Student(String firstName, String lastName, String email,
			Address address, PhoneNumber phone, String classStand) {
		super(firstName, lastName, email, address, phone);
		this.classStand = classStand;
	}

	/**
	 * Blank Constructor.
	 */
	public Student() {
		super();
		this.classStand = "blank";
	}

	/**
	 * Modified to String.
	 *
	 * @return String formatted
	 */
	@Override
	public String toString() {
		String addInfo;
		addInfo = String.format("%s\nClass Standing:\t\t\t %s", super.toString(),
				classStand);
		return addInfo;
	}

	/* (non-Javadoc)
	 * @see allpeople.Person#obType()
	 */
	@Override
	public String obType() {
		return "Student";
	}

	//getters
	/**
	 * Gets the class stand.
	 *
	 * @return the class stand
	 */
	public String getClassStand() {
		return classStand;
	}

	// setters
	/**
	 * Sets the class stand status.
	 *
	 * @param classStand the new class stand status
	 */
	public void setClassStand(String classStand) {
		this.classStand = classStand;
	}
}
