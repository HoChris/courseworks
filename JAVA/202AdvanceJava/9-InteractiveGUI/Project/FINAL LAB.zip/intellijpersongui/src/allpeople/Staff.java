/*
 * 
 */
package allpeople;

import java.util.ArrayList;

/**
 * The class {@code Staff} is a subclass from the {@code Employee} class
 * thus inherits the parameters from super class. This class adds the
 * parameter of what type of Job Title they are assigned.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Staff extends Employee {
	
	/** The job title. */
	private String jobTitle;

	/**
	 * Instantiates a new staff.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param pNum the phone numbers
	 * @param address the address
	 * @param office the office
	 * @param salary the salary
	 * @param jobTitle the job title
	 */
	public Staff(String firstName, String lastName, String email,
			ArrayList<PhoneNumber> pNum, Address address, String office,
			double salary, String jobTitle) {
		super(firstName, lastName, email, pNum, address, office, salary);
		this.jobTitle = jobTitle;
	}

	/**
	 * Instantiates a new staff.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param address the address
	 * @param phone the phone
	 * @param office the office
	 * @param salary the salary
	 * @param jobTitle the job title
	 */
	public Staff(String firstName, String lastName, String email,
			Address address, PhoneNumber phone, String office, double salary,
			String jobTitle) {
		super(firstName, lastName, email, address, phone, office, salary);
		this.jobTitle = jobTitle;
	}

	/**
	 * Instantiates a new staff.
	 */
	public Staff() {
		super();
		this.jobTitle = "blank";
	}

	/* (non-Javadoc)
	 * @see allpeople.Employee#toString()
	 */
	@Override
	public String toString() {
		String addInfo;
		addInfo = super.toString() + "\nTitle:\t\t\t\t " + jobTitle;
		return addInfo;
	}

	/* (non-Javadoc)
	 * @see allpeople.Employee#obType()
	 */
	@Override
	public String obType() {
		return "Staff";
	}

	//getters
	/**
	 * Gets the job title.
	 *
	 * @return the job title
	 */
	public String getJobTitle() {
		return jobTitle;
	}

	// setters
	/**
	 * Sets the job title.
	 *
	 * @param jobTitle the new job title
	 */
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
}
