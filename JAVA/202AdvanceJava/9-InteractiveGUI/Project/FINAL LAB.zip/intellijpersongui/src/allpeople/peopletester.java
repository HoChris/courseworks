package allpeople;

import java.util.Scanner;

public class peopletester {
	public static void main(String[] args) {

		// enter the file name to sort the list
		/*
		 * System.out.println("Please enter the file name: "); Scanner in = new
		 * Scanner(System.in); String nfile = in.nextLine(); FileReader file =
		 * new FileReader(file);
		 */

		// to see if it runs without input of file name
		FileReader file = new FileReader();
		Database a1 = new Database(file.getDaPeople());
		a1.printDatabase();
		// a1.printDatabase("person");
		a1.printDatabase("faculty");
		a1.printDatabase("Staff");
		a1.printDatabase("STUDENT");
		a1.printDatabase("EMployee");

		System.out.println("\nThe number of People is : "
				+ a1.getNumberofPeople());
		System.out.println("The number of Students is : "
				+ a1.getNumberofStudents());
		System.out.println("The number of Employees is : "
				+ a1.getNumberofEmployees());
		System.out.println("The number of Faculty is : "
				+ a1.getNumberofFaculty());
		System.out.println("The number of Staff is : " + a1.getNumberofStaff());
		int all = a1.getNumberofPeople() + a1.getNumberofStudents()
				+ a1.getNumberofEmployees() + a1.getNumberofFaculty()
				+ a1.getNumberofStaff();
		System.out.println("The number of ALL PEOPLE is: " + all);
		System.out.println("The number of Freshman: "
				+ a1.getNumberofStudensByClassStanding("freshman"));
		System.out.println("The number of Sophmores: "
				+ a1.getNumberofStudensByClassStanding("sophmore"));
		System.out.println("The number of Juniors: "
				+ a1.getNumberofStudensByClassStanding("junior"));
		System.out.println("The number of Seniors: "
				+ a1.getNumberofStudensByClassStanding("senior"));
		System.out.println("The number of Graduates: "
				+ a1.getNumberofStudensByClassStanding("graduate"));
		a1.displayEmployyesGreaterThanSalary();
		a1.displayEmployyesEqualToSalary();
		a1.displayEmployyesLesserThanSalary();

	}
}
		//junk test data
		//PhoneNumber a2 = new PhoneNumber("cell",323,509,9987);
		// Address a3 = new Address("asjkldf","sdfi","CA",123,0,92314);
		// Person a1 = new Person("chris","ho","dskjaf@.com",a3,a2);
		// Person a4 = new
		// Employee("chris","ho","dskjaf@.com",a3,a2,"sh 0a1",23002);
		// Person a5 = new Student("chris","ho","dskjaf@.com",a3,a2,"Graduate");
		// Person a6 = new
		// Faculty("chris","ho","dskjaf@.com",a3,a2,"sh 0a1",23002,"3am-5pm","Fulltime");
		// Staff a7 = new Staff();
		// System.out.println(a7);