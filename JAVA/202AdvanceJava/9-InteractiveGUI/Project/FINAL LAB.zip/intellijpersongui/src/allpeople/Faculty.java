package allpeople;

import java.util.ArrayList;

/**
 * The class {@code Faculty} is a subclass from the {@code Employee} class
 * thus inherits the parameters from super class. This class adds the
 * parameters of available office hours and working status they are assigned.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Faculty extends Employee {
	
	/** The Office Hours. */
	private String offHrs;
	
	/** The rank contains Full time or Part time. */
	private String rank;

	/**
	 * Instantiates a new faculty.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param pNum the phone numbers
	 * @param address the address
	 * @param office the office
	 * @param salary the salary
	 * @param offHrs the office hours
	 * @param rank the rank of full/part time
	 */
	public Faculty(String firstName, String lastName, String email,
			ArrayList<PhoneNumber> pNum, Address address, String office,
			double salary, String offHrs, String rank) {
		super(firstName, lastName, email, pNum, address, office, salary);
		this.offHrs = offHrs;
		this.rank = rank;
	}

	/**
	 * Instantiates a new faculty.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param address the address
	 * @param phone the phone
	 * @param office the office
	 * @param salary the salary
	 * @param offHrs the office hours
	 * @param rank the rank of full/part time
	 */
	public Faculty(String firstName, String lastName, String email,
			Address address, PhoneNumber phone, String office, double salary,
			String offHrs, String rank) {
		super(firstName, lastName, email, address, phone, office, salary);
		this.offHrs = offHrs;
		this.rank = rank;
	}

	/**
	 * Instantiates a new faculty.
	 */
	public Faculty() {
		super();
		this.offHrs = "4pm-9pm";
		this.rank = "blank";
	}

	/* (non-Javadoc)
	 * @see allpeople.Employee#toString()
	 */
	@Override
	public String toString() {
		String addInfo;
		addInfo = super.toString() + "\nFaculty:\t\t\t " + offHrs
				+ "\nRank:\t\t\t\t " + rank;
		return addInfo;
	}

	/* (non-Javadoc)
	 * @see allpeople.Employee#obType()
	 */
	@Override
	public String obType() {
		return "Faculty";
	}

	//getters
	/**
	 * Gets the office hours.
	 *
	 * @return the off hrs
	 */
	public String getOffHrs() {
		return offHrs;
	}

	/**
	 * Gets the rank of part time or full time.
	 *
	 * @return the rank
	 */
	public String getRank() {
		return rank;
	}

	// setters
	/**
	 * Sets the office hours.
	 *
	 * @param offHrs the new office hours
	 */
	public void setOffHrs(String offHrs) {
		this.offHrs = offHrs;
	}

	/**
	 * Sets the rank.
	 *
	 * @param rank the new rank
	 */
	public void setRank(String rank) {
		this.rank = rank;
	}
}
