package allpeople;

/**
 * The Class {@code Address} stores the Address information
 * of a Person. Specifically it stores a persons mailing address.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Address {
	
	/** The street name, city , and state. */
	private String streetName, city, state;
	
	/** The street number zip code, apartment number. */
	private int streetNum, zipCode, aptNum;

	/**
	 * Instantiates a new address.
	 *
	 * @param streetName the street name
	 * @param city the city
	 * @param state the state
	 * @param streetNum the street number
	 * @param aptNum the apartment number
	 * @param zipCode the zip code
	 */
	public Address(String streetName, String city, String state, int streetNum,
			int aptNum, int zipCode) {
		this.streetName = streetName;
		this.city = city;
		this.state = state;
		this.streetNum = streetNum;
		this.aptNum = aptNum;
		this.zipCode = zipCode;
	}

	/**
	 * Instantiates a new address.
	 */
	public Address() {
		this.streetName = "blank";
		this.city = "blank";
		this.state = "blank";
		this.streetNum = 100;
		this.aptNum = 0;
		this.zipCode = 90210;
	}

/*	public String toString() {
		if (aptNum > 0) {
			String addInfo = streetNum + " " + streetName + " Apt/Suite:"
					+ aptNum + "\n\t\t\t\t " + city + ", " + state + ", "
					+ zipCode + "\n";
			return addInfo;
		} else {
			String addInfo = streetNum + " " + streetName + "\n\t\t\t\t "
					+ city + ", " + state + ", " + zipCode +"\n";
			return addInfo;
		}*/
	/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
public String toString() {
		if (aptNum > 0) {
			String addInfo = streetNum + " " + streetName + " Apt/Suite:"
					+ aptNum + "\n" + city + ", " + state + ", "
					+ zipCode + "\n";
			return addInfo;
		} else {
			String addInfo = streetNum + " " + streetName + "\n "
					+ city + ", " + state + ", " + zipCode +"\n";
			return addInfo;
		}

	}
	//Getters

	/**
	 * Gets the street name.
	 *
	 * @return the street name
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Gets the street number.
	 *
	 * @return the street number
	 */
	public int getStreetNum() {
		return streetNum;
	}

	/**
	 * Gets the zip code.
	 *
	 * @return the zip code
	 */
	public int getZipCode() {
		return zipCode;
	}

	/**
	 * Gets the apartment number.
	 *
	 * @return the apartment number
	 */
	public int getAptNum() {
		return aptNum;
	}

	// setters

	/**
	 * Sets the apartment number
	 *
	 * @param aptNum the new apartment number
	 */
	public void setAptNum(int aptNum) {
		this.aptNum = aptNum;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Sets the street name.
	 *
	 * @param streetName the new street name
	 */
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	/**
	 * Sets the street number.
	 *
	 * @param streetNum the new street number
	 */
	public void setStreetNum(int streetNum) {
		this.streetNum = streetNum;
	}

	/**
	 * Sets the zip code.
	 *
	 * @param zipCode the new zip code
	 */
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
}
