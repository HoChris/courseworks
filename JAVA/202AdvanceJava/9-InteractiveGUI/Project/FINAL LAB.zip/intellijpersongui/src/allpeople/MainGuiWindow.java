package allpeople;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.scene.Scene;
import java.io.File;
import java.util.ArrayList;



/**
 * The Class {@code MainGuiWindow} is the GUI. Using a combination of TreeView,
 * TableView, and Menu bar to keep everything clean and organized. The TableView 
 * enables the User to sort and move each column to their liking.
 *
 *
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class MainGuiWindow extends Application{

    /** The left tr is the Left TreeView on the GUI. */
    private TreeView<String> leftTr;
    
    /** in data is main window that shows all of the data. */
    private TableView<Person> inData;
    
    /** quantity data is the counted number of object types from the database. */
    private TableView<String> quantityData;
    
    /** The f_ file is the file object that stores the .cvs file from the {@code FileChooser}. */
    private File f_File;
    
    /** The f_ filereader stores the Arraylist of person object after its been populated with {@code Person}. */
    private FileReader f_Filereader;
    
    /** The scene. */
    private Scene scene;
    
    /** The primary stage. */
    private Stage primaryStage;
    
    /** The p_ back pane is the window that everything is set on top of. */
    private Pane p_BackPane;
    
    /** The p_ mother pane is the pane used to organize the TreeView to the left, TableView to the center,
     * MenuBar at the top,  and the Search at the bottom */
    private BorderPane p_MotherPane;
    
    /** The p_ center field is the main window that displays all ouput of the results . */
    private ScrollPane p_CenterField;
    
    /** The p_ add page is the pane that shows when adding a new person to the list. */
    private GridPane p_AddPage;
    
    /** The p_ search is the pane that contains the fields and button. */
    private HBox p_Search;
    
    /** The p_ left tr is the pane that contains the TreeView. */
    private VBox p_LeftTr;
    
    /** The t_ first n is the Text field on for the First name. */
    private TextField t_FirstN = new TextField();
    
    /** The t_ last n is the Text field on for the Last name. */
    private TextField t_LastN = new TextField();
    
    /** The b_ search is the Search button . */
    private Button b_Search = new Button("Search");

    /* (non-Javadoc)
     * @see javafx.application.Application#start(javafx.stage.Stage)
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane p_BackPane = new Pane();
        primaryStage.setTitle("The GUI");

        //Create 1st Menu-------------------------------------
        Menu p_Start = new Menu("_Start Here");

        //Menu items
        MenuItem b_Import = new MenuItem("Import CSV...");
        b_Import.setOnAction(e -> {
            FileChooser inFile = new FileChooser();
            inFile.setTitle("Open File for Database");
            inFile.setInitialDirectory( new File(System.getProperty("user.home")));
            inFile.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("CSV", "*.csv"));
            this.f_File = inFile.showOpenDialog(primaryStage);
            if(getF_File() != null) {
                inData.setItems(getFilereader());
               
            }
        });

        MenuItem b_Exit = new MenuItem("Exit");
        b_Exit.setOnAction(e-> primaryStage.close());
        p_Start.getItems().addAll(b_Import,b_Exit);

        //Actual Bar
        MenuBar p_Bar = new MenuBar();
        p_Bar.getMenus().addAll(p_Start);


        //COLUMnS FOR TABLE-----------------------------------
        //First and last name
        TableColumn<Person, String> nameCol = new TableColumn<>("First Name");
        nameCol.setMinWidth(100);
        nameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));

        TableColumn<Person, String> nameCol2 = new TableColumn<>("Last Name");
        nameCol2.setMinWidth(100);
        nameCol2.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));

        //Email
        TableColumn<Person, String> emailCol = new TableColumn<>("Email");
        emailCol.setMinWidth(200);
        emailCol.setCellValueFactory(new PropertyValueFactory<Person, String>("email"));

        //Address
        TableColumn<Person, Address> addressCol = new TableColumn<>("Address");
        addressCol.setMinWidth(230);
        addressCol.setCellValueFactory(new PropertyValueFactory<Person, Address>("address"));

        //Phonenumbers
        TableColumn<Person, PhoneNumber> phoneCol = new TableColumn<>("Phone Number(s)");
        phoneCol.setMinWidth(175);
        phoneCol.setCellValueFactory(new PropertyValueFactory<Person, PhoneNumber>("phone"));

/*        //Phonenumbers
        TableColumn<Person, PhoneNumber> phoneCol = new TableColumn<>("Phone Number(s)");
        phoneCol.setMinWidth(175);
        phoneCol.setCellValueFactory(new PropertyValueFactory<Person, PhoneNumber>("pnum"));*/

        //Salary
        TableColumn<Person, String> salaryCol = new TableColumn<>("Salary");
        salaryCol.setMinWidth(150);
        salaryCol.setCellValueFactory(new PropertyValueFactory<Person, String>("salary"));


        //Office
        TableColumn<Person, String> officeCol = new TableColumn<>("Office Location");
        officeCol.setMinWidth(150);
        officeCol.setCellValueFactory(new PropertyValueFactory<Person, String>("office"));

        //OfficeHours
        TableColumn<Person, String> offHrsCol = new TableColumn<>("Office Hours");
        offHrsCol.setMinWidth(125);
        offHrsCol.setCellValueFactory(new PropertyValueFactory<Person, String>("offHrs"));

        //Partime-Fulltime
        TableColumn<Person, String> partFullCol = new TableColumn<>("Full/Part Time");
        partFullCol.setMinWidth(125);
        partFullCol.setCellValueFactory(new PropertyValueFactory<Person, String>("rank"));

        //Class Rank
        TableColumn<Person, String> classCol = new TableColumn<>("Class Rank");
        classCol.setMinWidth(125);
        classCol.setCellValueFactory(new PropertyValueFactory<Person, String>("classStand"));

        //Jobtitle
        TableColumn<Person, String> jobCol = new TableColumn<>("Job Title");
        jobCol.setMinWidth(175);
        jobCol.setCellValueFactory(new PropertyValueFactory<Person, String>("jobTitle"));

        //Numbers
        TableColumn<String, String> numbersCol =
                new TableColumn<String, String>("Total Number In Database");
        numbersCol.setMinWidth(250);
        numbersCol.setCellValueFactory(new PropertyValueFactory<String, String>("this"));
        //Create TableView
        inData = new TableView<>();
        quantityData = new TableView<>();

        //Create treeview and branches
        TreeItem<String> root, dispInfo, dispNumbers, dispSalary, dispAddRemove;

        //root
        root = new TreeItem<>();
        root.setExpanded(true);

        //dispInfo
        dispInfo = branches("Display Information", root);
        branches("Entire Database", dispInfo);
        branches("People", dispInfo);
        branches("Employees", dispInfo);
        branches("Staff", dispInfo);
        branches("Students", dispInfo);
        branches("Faculty", dispInfo);

        //dispNumbers
        dispNumbers = branches("Display Quantities", root);
        branches("#People", dispNumbers);
        branches("#Employees", dispNumbers);
        branches("#Faculty", dispNumbers);
        branches("#Staff", dispNumbers);
        branches("#Students", dispNumbers);
        branches("#Freshman", dispNumbers);
        branches("#Sophomores", dispNumbers);
        branches("#Juniors", dispNumbers);
        branches("#Seniors", dispNumbers);
        branches("#Graduates", dispNumbers);

        //dispSalary
        dispSalary = branches("Display by Salaries", root);
        branches("Greater than 30,000", dispSalary);
        branches("Equal to 30,000", dispSalary);
        branches("Less than 30,000", dispSalary);

        //add/remove
        dispAddRemove = branches("Modify Database", root);
        branches("Add New Person",dispAddRemove);
        branches("Remove A Person",dispAddRemove);

        //create tree
        leftTr = new TreeView<>(root);
        leftTr.setShowRoot(false);
        leftTr.setPrefHeight(1000);
        leftTr.getSelectionModel().selectedItemProperty().
                addListener((e, oldValue, newValue) -> {
                if (newValue == dispInfo || newValue == dispNumbers
                        || newValue == dispSalary || newValue == dispAddRemove) {
                    //fill later

                } else if (newValue != null) {
                    String item = newValue.getValue();
                    try {
                            p_MotherPane.setCenter(p_CenterField);
                        if (item.equalsIgnoreCase("Entire Database")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    salaryCol, officeCol, offHrsCol,
                                    partFullCol, classCol, jobCol);
                            inData.setItems(getFilereader());
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("People")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol);
                            inData.setItems(setTableItems("Person"));
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("Employees")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol, officeCol, salaryCol);
                            inData.setItems(setTableItems("Employee"));
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("Staff")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    officeCol, jobCol, salaryCol);
                            inData.setItems(setTableItems("Staff"));
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("Students")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    classCol);
                            inData.setItems(setTableItems("Student"));
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("Faculty")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    officeCol, offHrsCol, salaryCol, partFullCol);
                            inData.setItems(setTableItems("Faculty"));
                            p_CenterField.setContent(inData);
                        } else if (item.equalsIgnoreCase("#People")) {
                            quantityData.getColumns().setAll(numbersCol);
                            quantityData.setItems(setNumberItems("person"));
                            p_CenterField.setContent(quantityData);
                        }
                        else if (item.equalsIgnoreCase("#Employees")) {

                        } else if (item.equalsIgnoreCase("#Faculty")) {

                        } else if (item.equalsIgnoreCase("#Staff")) {

                        } else if (item.equalsIgnoreCase("#Student")) {

                        } else if (item.equalsIgnoreCase("#Freshman")) {

                        } else if (item.equalsIgnoreCase("#Sophomores")) {

                        } else if (item.equalsIgnoreCase("#Juniors")) {

                        } else if (item.equalsIgnoreCase("#Seniors")) {

                        } else if (item.equalsIgnoreCase("#Graduates")) {

                        } else if (item.equalsIgnoreCase("Greater than 30,000")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    salaryCol, officeCol, offHrsCol,
                                    partFullCol, jobCol);
                            p_CenterField.setContent(inData);
                            inData.setItems(setBySalary(">"));
                        } else if (item.equalsIgnoreCase("Equal to 30,000")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    salaryCol, officeCol, offHrsCol,
                                    partFullCol, jobCol);
                            p_CenterField.setContent(inData);
                            inData.setItems(setBySalary("=="));
                        } else if (item.equalsIgnoreCase("Less than 30,000")) {
                            inData.getColumns().setAll(nameCol, nameCol2,
                                    addressCol, phoneCol, emailCol,
                                    salaryCol, officeCol, offHrsCol,
                                    partFullCol, jobCol);
                            inData.setItems(setBySalary("<"));
                            p_CenterField.setContent(inData);
                        }
                        else if (item.equalsIgnoreCase("Add New Person")) {
                                addPerson();
                        }
                        else if (item.equalsIgnoreCase("Remove A Person")){

                        }

                    } catch (NullPointerException ex) {
                        AlertMsg.displayBox("Error has occurred", "So this is awkward... Ah either" +
                                "\n The file didnt load right, or you just " +
                                "\nplain didn't load the damn thing.");
                    }

                }
        });


        //layouts--------------------------------------
        //tree
        p_LeftTr = new VBox();
        p_LeftTr.setPrefHeight(900);
        p_LeftTr.getChildren().add(leftTr);

        //bottom
        p_Search = new HBox();
        p_Search.getChildren().addAll(t_FirstN, t_LastN, b_Search);
        t_FirstN.setPromptText("First Name");
        t_LastN.setPromptText("Last Name");
        b_Search.setOnAction(e -> {
            if(searchClicked()== true) {
                for(Person x : inData.getItems()) {
                    if (x.getFirstName().equalsIgnoreCase(t_FirstN.getText()) &&
                            x.getLastName().equalsIgnoreCase(t_LastN.getText())) {
                        inData.getSelectionModel().select(x);
                    }
                }
            }
            else {
                AlertMsg.displayBox("Not Found", "Person was not found.\n" +
                        "Please Check Spelling of First and Last Name.");
            }
        });
        p_Search.setSpacing(20);
        p_Search.setPadding(new Insets(10));
        p_Search.setAlignment(Pos.CENTER_RIGHT);

        //Tableview pane
        p_CenterField = new ScrollPane();
        p_CenterField.setContent(inData);
        p_CenterField.setPadding(new Insets(12));
        p_CenterField.setPrefSize(800, 800);
        p_CenterField.setFitToHeight(true);
        p_CenterField.setFitToWidth(true);

        //everything goes on this pane
        p_MotherPane = new BorderPane();
        p_MotherPane.setLeft(p_LeftTr);
        p_MotherPane.setCenter(p_CenterField);
        p_MotherPane.setTop(p_Bar);
        p_MotherPane.setBottom(p_Search);

        p_BackPane.getChildren().add(p_MotherPane);

        //Scene and Show
        Scene scene = new Scene(p_BackPane);
        primaryStage.setScene(scene);
        primaryStage.show();

    }//endofprimstage

    //to make branches for tree node
    /**
     * Branches method is used to clean up the code a bit by making a 
     * new TreeItem to populate the Tree View on the left hand side of the GUI. This method 
     * takes in a {@code String} to name the branch to be displayed and the TreeItem parent to
     * belong to.
     *
     * @param string the string
     * @param parent the parent
     * @return the tree item
     */
    public TreeItem<String>branches(String string, TreeItem<String> parent){
        TreeItem<String> theItem = new TreeItem<>(string);
        theItem.setExpanded(true);
        parent.getChildren().add(theItem);
        return theItem;
    }
    //get the data into obseravablelist
    /**
     * Gets the filereader and sets the Arraylist of Person Objects into an 
     * ObservableList of Person object in order to use the data to by displayed onto the 
     * centerfield window.
     *
     * @return the filereader
     */
    public ObservableList<Person> getFilereader(){
        f_Filereader = new FileReader(getF_File());
        ObservableList<Person> daData = FXCollections.observableArrayList(f_Filereader.getDoneList());
        return daData;
    }
    
    /**
     * Sets what Type of Person to be displayed as the person picks the Tree Items on the left hand side.
     * The way this method works is it creates a temporary Arraylist of Person objects to be populated
     * by a choosing database method the users picks by selecting a tree item.
     *
     * @param objectType the is the assigned string from the selected Tree Item
     * @return the observable list
     */
    public ObservableList<Person> setTableItems(String objectType){
        ArrayList<Person> temp = new ArrayList<Person>();
        Database typeClass = new Database(f_Filereader.getDoneList());
        temp = typeClass.setTypeDatabase(objectType);
        ObservableList<Person> setTableData = FXCollections.observableArrayList(temp);
        return setTableData;

    }
    
    /**
     * Sets what Employee to be displayed by salary amount when a Tree Item is selected.
     * 
     *
     * @param objectType the is the assigned string from the selected Tree Item
     * @return the observable list
     */
    public ObservableList<Person> setBySalary(String objectType){
        ArrayList<Person> temp = new ArrayList<Person>();
        Database typeClass = new Database(f_Filereader.getDoneList());
        temp = typeClass.setOrderSalary(objectType);
        ObservableList<Person> setTableData = FXCollections.observableArrayList(temp);
        return setTableData;

    }
    //sets the counted numbers from database into observable arraylist
    /**
     * Sets the number items.
     *
     * @param objType the obj type
     * @return the observable list
     */
    public ObservableList<String> setNumberItems(String objType){
        ArrayList<String> temp = new ArrayList<String>();
        Database typeClass = new Database(f_Filereader.getDoneList());
        temp = typeClass.setNumberCount(objType);
        ObservableList<String> setTableData = FXCollections.observableArrayList(temp);
        return setTableData;

    }
    //search button clicked
    /**
     * Search clicked is a method used to get the user input of the specified 
     * first and last name to be searched for in the database. If there is a match 
     * the match is then displayed and hilighted in the TableView then clears the 
     * fields.
     *
     * @return true, if successful
     */
    public boolean searchClicked(){
        boolean found = false;
        if(getF_File() != null) {
            inData.setItems(getFilereader());
            for(Person x : inData.getItems()){
                if(x.getFirstName().equalsIgnoreCase(t_FirstN.getText()) &&
                        x.getLastName().equalsIgnoreCase(t_LastN.getText())) {
                    inData.getSelectionModel().select(x);
                    found = true;
                }
            }
            t_FirstN.clear();
            t_LastN.clear();
        }
        return found;
    }
    //Add clicked
    /**
     * Adds the person to the Observable List of Person objects. The method works
     * by getting user inputs to and sets them using setter methods of the necessary 
     * class then adds it to the entire database.
     */
    public void addPerson (){
        Person addNewPerson, addNewPerson2;
        Address addAddress;
        PhoneNumber addPhone;
        Button b_add = new Button("Add");
        Button b_clear = new Button("Clear");
        p_AddPage = new GridPane();
        p_AddPage.setPadding(new Insets(25));
        p_AddPage.setVgap(25);
        p_AddPage.setHgap(35);
        TextField fName,lName,eMail,phone,address,
                office,salary,offhrs,rank,classStanding;
        Label l_FName,l_LName,l_eMail,l_Phone,l_Address,
                l_Office,l_Salary,l_Offhrs,l_Rank,l_ClassStanding;
        l_FName = new Label("First Name");
        l_LName = new Label("Last Name");
        l_eMail = new Label("eMail");
        l_Phone = new Label("Phone");
        l_Address = new Label("Address");
        fName = new TextField();
        lName = new TextField();
        eMail = new TextField();
        phone = new TextField();
        phone.setPromptText("Home: 555-555-5555");
        addPhone = new PhoneNumber();
        /*need to figure this out
        String[] splitPhone = phone.getText().split("-");
        addPhone.setAreaCode(Integer.parseInt(splitPhone[0]));*/
        address = new TextField();
        address.setPromptText("123 Ralph St. Pasadena, CA 91770");
        l_Office = new Label("Office");
        l_Salary = new Label("Salary");
        l_Offhrs = new Label("Office Hours");
        l_Rank = new Label("Part/Full Time");
        l_ClassStanding = new Label("Class Title");
        office = new TextField();
        salary = new TextField();
        salary.setPromptText("25,000");
        offhrs = new TextField();
        offhrs.setPromptText("9AM-1:30PM");
        rank = new TextField();
        rank.setPromptText("FullTime");
        classStanding = new TextField();
        classStanding.setPromptText("Freshman");
        addNewPerson = new Person();
        b_add.setMinSize(125,25);
        b_add.setOnAction(e-> {
            //fill later
            addNewPerson.setFirstName(fName.getText());
            addNewPerson.setLastName(lName.getText());
            addNewPerson.setEmail(eMail.getText());

        });
        b_clear.setMinSize(125,25);
        b_clear.setOnAction(e->{
            fName.clear();
            lName.clear();
            eMail.clear();
            phone.clear();
            address.clear();
            office.clear();
            salary.clear();
            offhrs.clear();
            rank.clear();
            classStanding.clear();
        });
        GridPane.setConstraints(l_FName, 0, 0);
        GridPane.setConstraints(fName, 1, 0);
        GridPane.setConstraints(l_LName, 0, 1);
        GridPane.setConstraints(lName, 1, 1);
        GridPane.setConstraints(l_eMail, 0, 2);
        GridPane.setConstraints(eMail, 1, 2);
        GridPane.setConstraints(l_Address, 0, 3);
        GridPane.setConstraints(address, 1, 3);
        GridPane.setConstraints(l_Phone, 0, 4);
        GridPane.setConstraints(phone, 1, 4);
        GridPane.setConstraints(l_Office, 2, 0);
        GridPane.setConstraints(office, 3, 0);
        GridPane.setConstraints(l_Salary, 2, 1);
        GridPane.setConstraints(salary, 3, 1);
        GridPane.setConstraints(l_Offhrs, 2, 2);
        GridPane.setConstraints(offhrs, 3, 2);
        GridPane.setConstraints(l_Rank, 2, 3);
        GridPane.setConstraints(rank, 3, 3);
        GridPane.setConstraints(l_ClassStanding, 2, 4);
        GridPane.setConstraints(classStanding, 3, 4);
        GridPane.setConstraints(b_add, 2, 5);
        GridPane.setConstraints(b_clear, 3, 5);

        p_AddPage.getChildren().addAll(l_FName,fName,l_LName,lName,
                l_eMail,eMail,l_Address,address,l_Phone,phone,
                l_Office,office,l_Salary,salary,l_Offhrs,offhrs,
                l_Rank,rank,l_ClassStanding,classStanding,b_add,b_clear);
        p_MotherPane.setCenter(p_AddPage);

    }
    
    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    //get file object
    /**
     * Gets the f_ file.
     *
     * @return the f_ file
     */
    public File getF_File (){
        return f_File;
    }
}//endofapp
