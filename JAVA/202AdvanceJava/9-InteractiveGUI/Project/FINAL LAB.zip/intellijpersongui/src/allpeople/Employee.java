package allpeople;

import java.util.ArrayList;

/**
 * The class {@code Employee} is a subclass from the {@code Person} class
 * thus inherits the parameters from super class. This class adds the
 * parameter of what type of Class standing status they are assigned.
 * 
 * @author Christopher Ho
 * @version 1.0
 * @see allpeople.Person
 * @since JDK8.0
 */
public class Employee extends Person {
	
	/** The office. */
	private String office;
	
	/** The salary. */
	private double salary;

	/**
	 * Instantiates a new employee.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param pNum the phone numbers
	 * @param address the address
	 * @param office the office
	 * @param salary the salary
	 */
	public Employee(String firstName, String lastName, String email,
			ArrayList<PhoneNumber> pNum, Address address, String office,
			double salary) {
		super(firstName, lastName, email, pNum, address);
		this.office = office;
		this.salary = salary;
	}

	/**
	 * Instantiates a new employee.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param address the address
	 * @param phone the phone
	 * @param office the office
	 * @param salary the salary
	 */
	public Employee(String firstName, String lastName, String email,
			Address address, PhoneNumber phone, String office, double salary) {
		super(firstName, lastName, email, address, phone);
		this.office = office;
		this.salary = salary;
	}

	/**
	 * Instantiates a new employee.
	 */
	public Employee() {
		super();
		this.office = "blank";
		this.salary = 0.0;
	}

	/* (non-Javadoc)
	 * @see allpeople.Person#toString()
	 */
	@Override
	public String toString() {
		String addInfo;

		addInfo = String.format(
				"%s\nOffice Location:\t\t %s \nSalary:\t\t\t\t $%.2f",
				super.toString(), office, salary);
		return addInfo;
	}

	/* (non-Javadoc)
	 * @see allpeople.Person#obType()
	 */
	@Override
	public String obType() {
		return "Employee";
	}

	//getters
	/**
	 * Gets the salary.
	 *
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * Gets the office.
	 *
	 * @return the office
	 */
	public String getOffice() {
		return office;
	}

	// setters
	/**
	 * Sets the office.
	 *
	 * @param office the new office
	 */
	public void setOffice(String office) {
		this.office = office;
	}

	/**
	 * Sets the salary.
	 *
	 * @param salary the new salary
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
}
